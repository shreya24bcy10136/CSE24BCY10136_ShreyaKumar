package dao;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import model.Victim;
import org.bson.Document;
import org.bson.conversions.Bson;
import util.MongoDBConnection;

import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Victim entity.
 */
public class VictimDAO {
    private static final String COLLECTION_NAME = "victims";

    private MongoCollection<Document> getCollection() {
        MongoDatabase db = MongoDBConnection.getDatabase();
        if (db == null) {
            throw new RuntimeException("Database connection is not available.");
        }
        return db.getCollection(COLLECTION_NAME);
    }

    /**
     * Converts a Victim object to a MongoDB Document.
     */
    private Document victimToDocument(Victim v) {
        return new Document("victimId", v.getVictimId())
                .append("victimName", v.getVictimName())
                .append("age", v.getAge())
                .append("gender", v.getGender())
                .append("phone", v.getPhone())
                .append("email", v.getEmail())
                .append("address", v.getAddress())
                .append("city", v.getCity())
                .append("state", v.getState());
    }

    /**
     * Converts a MongoDB Document to a Victim object.
     */
    private Victim documentToVictim(Document doc) {
        if (doc == null) return null;
        return new Victim(
                doc.getString("victimId"),
                doc.getString("victimName"),
                doc.getInteger("age", 0),
                doc.getString("gender"),
                doc.getString("phone"),
                doc.getString("email"),
                doc.getString("address"),
                doc.getString("city"),
                doc.getString("state")
        );
    }

    /**
     * Inserts a new victim record.
     */
    public boolean addVictim(Victim victim) {
        try {
            getCollection().insertOne(victimToDocument(victim));
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to add victim: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves all victims.
     */
    public List<Victim> getAllVictims() {
        List<Victim> victims = new ArrayList<>();
        try {
            for (Document doc : getCollection().find()) {
                victims.add(documentToVictim(doc));
            }
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to retrieve victims: " + e.getMessage());
        }
        return victims;
    }

    /**
     * Finds a victim by their ID.
     */
    public Victim getVictimById(String victimId) {
        try {
            Document doc = getCollection().find(Filters.eq("victimId", victimId)).first();
            return documentToVictim(doc);
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to find victim by ID: " + e.getMessage());
            return null;
        }
    }

    /**
     * Updates an existing victim record.
     */
    public boolean updateVictim(Victim victim) {
        try {
            Bson filter = Filters.eq("victimId", victim.getVictimId());
            Bson updates = Updates.combine(
                    Updates.set("victimName", victim.getVictimName()),
                    Updates.set("age", victim.getAge()),
                    Updates.set("gender", victim.getGender()),
                    Updates.set("phone", victim.getPhone()),
                    Updates.set("email", victim.getEmail()),
                    Updates.set("address", victim.getAddress()),
                    Updates.set("city", victim.getCity()),
                    Updates.set("state", victim.getState())
            );
            getCollection().updateOne(filter, updates);
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to update victim: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deletes a victim record by ID.
     */
    public boolean deleteVictim(String victimId) {
        try {
            getCollection().deleteOne(Filters.eq("victimId", victimId));
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to delete victim: " + e.getMessage());
            return false;
        }
    }
}
