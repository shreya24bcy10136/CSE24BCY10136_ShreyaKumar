package api;

import service.VictimService;
import service.ComplaintService;
import service.OfficerService;
import service.EvidenceService;
import model.Complaint;
import util.MongoDBConnection;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Controller exposing system summary statistics and database connectivity status.
 */
@RestController
@RequestMapping("/api/summary")
@Tag(name = "System Summary", description = "Endpoints for checking system summary stats and MongoDB connection status")
public class SummaryController {
    private final VictimService victimService = new VictimService();
    private final OfficerService officerService = new OfficerService();
    private final ComplaintService complaintService = new ComplaintService();
    private final EvidenceService evidenceService = new EvidenceService();

    @GetMapping
    public SummaryReport getSummaryReport() {
        boolean dbConnected = MongoDBConnection.getDatabase() != null;

        int totalVictims = 0;
        int totalOfficers = 0;
        int totalEvidence = 0;
        int totalComplaints = 0;
        Map<String, Integer> statusBreakdown = new HashMap<>();
        statusBreakdown.put("Pending", 0);
        statusBreakdown.put("Under Investigation", 0);
        statusBreakdown.put("Resolved", 0);

        if (dbConnected) {
            try {
                totalVictims = victimService.getAllVictims().size();
                totalOfficers = officerService.getAllOfficers().size();
                totalEvidence = evidenceService.getAllEvidence().size();
                
                var complaints = complaintService.getAllComplaints();
                totalComplaints = complaints.size();

                for (Complaint c : complaints) {
                    String status = c.getStatus();
                    if (status != null) {
                        if (status.equalsIgnoreCase("pending")) {
                            statusBreakdown.put("Pending", statusBreakdown.get("Pending") + 1);
                        } else if (status.equalsIgnoreCase("under investigation") || status.equalsIgnoreCase("under_investigation")) {
                            statusBreakdown.put("Under Investigation", statusBreakdown.get("Under Investigation") + 1);
                        } else if (status.equalsIgnoreCase("resolved")) {
                            statusBreakdown.put("Resolved", statusBreakdown.get("Resolved") + 1);
                        }
                    }
                }
            } catch (Exception e) {
                dbConnected = false;
            }
        }

        return new SummaryReport(
                totalVictims,
                totalOfficers,
                totalEvidence,
                totalComplaints,
                statusBreakdown,
                dbConnected
        );
    }
}
