# download_dependencies.ps1
$ProgressPreference = 'SilentlyContinue'

$projectRoot = $PSScriptRoot
$libDir = Join-Path $projectRoot "lib"
$scratchDir = Split-Path $projectRoot -Parent
$jdkDestDir = Join-Path $scratchDir "jdk17"

# 1. Download MongoDB Sync Driver JARs from Maven Central
$jars = @(
    @{
        Url = "https://repo1.maven.org/maven2/org/mongodb/bson/4.11.1/bson-4.11.1.jar"
        File = "bson-4.11.1.jar"
    },
    @{
        Url = "https://repo1.maven.org/maven2/org/mongodb/mongodb-driver-core/4.11.1/mongodb-driver-core-4.11.1.jar"
        File = "mongodb-driver-core-4.11.1.jar"
    },
    @{
        Url = "https://repo1.maven.org/maven2/org/mongodb/mongodb-driver-sync/4.11.1/mongodb-driver-sync-4.11.1.jar"
        File = "mongodb-driver-sync-4.11.1.jar"
    }
)

Write-Host "Checking MongoDB Sync Driver dependencies..."
foreach ($jar in $jars) {
    $targetPath = Join-Path $libDir $jar.File
    if (-not (Test-Path $targetPath)) {
        Write-Host "Downloading $($jar.File) from Maven Central..."
        Invoke-WebRequest -Uri $jar.Url -OutFile $targetPath
        Write-Host "Downloaded $($jar.File) successfully."
    } else {
        Write-Host "$($jar.File) is already present."
    }
}

# 2. Check for local JDK 17 installation
$javacPath = Join-Path $jdkDestDir "bin\javac.exe"
if (-not (Test-Path $javacPath)) {
    $jdkZipPath = Join-Path $scratchDir "jdk17.zip"
    Write-Host "Local JDK 17 not found. Downloading Eclipse Temurin JDK 17 ZIP..."
    $jdkUrl = "https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/adoptium"
    
    Write-Host "Downloading JDK 17 ZIP..."
    Invoke-WebRequest -Uri $jdkUrl -OutFile $jdkZipPath
    Write-Host "JDK 17 ZIP downloaded successfully. Extracting..."
    
    # Create temp extraction folder
    $tempExtractDir = Join-Path $scratchDir "jdk17_temp"
    if (Test-Path $tempExtractDir) { Remove-Item -Recurse -Force $tempExtractDir }
    New-Item -ItemType Directory -Path $tempExtractDir | Out-Null
    
    # Extract
    Expand-Archive -Path $jdkZipPath -DestinationPath $tempExtractDir
    
    # Temurin extract puts everything under a folder like jdk-17.0.x+y. Locate it.
    $extractedFolder = Get-ChildItem $tempExtractDir | Select-Object -First 1
    if ($extractedFolder) {
        Move-Item -Path $extractedFolder.FullName -Destination $jdkDestDir
        Write-Host "JDK 17 extracted to $jdkDestDir."
    } else {
        Write-Error "Failed to locate extracted JDK folder."
    }
    
    # Cleanup zip and temp dir
    Remove-Item -Force $jdkZipPath
    Remove-Item -Recurse -Force $tempExtractDir
} else {
    Write-Host "JDK 17 is already present at $jdkDestDir."
}

Write-Host "All dependencies checked and set up!"
