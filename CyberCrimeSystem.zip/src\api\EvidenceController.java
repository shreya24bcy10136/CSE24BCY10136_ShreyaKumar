package api;

import model.Evidence;
import service.EvidenceService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Controller exposing Digital Evidence Management REST APIs.
 */
@RestController
@RequestMapping("/api/evidence")
@Tag(name = "Evidence Management", description = "CRUD and query operations for digital evidence records linked to complaints")
public class EvidenceController {
    private final EvidenceService evidenceService = new EvidenceService();

    @GetMapping
    public List<Evidence> getAllEvidence() {
        return evidenceService.getAllEvidence();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Evidence> getEvidenceById(@PathVariable String id) {
        Evidence evidence = evidenceService.getEvidenceById(id);
        if (evidence == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(evidence);
    }

    @PostMapping
    public ResponseEntity<ApiResponse> addEvidence(@RequestBody Evidence evidence) {
        String result = evidenceService.addEvidence(evidence);
        return buildResponse(result);
    }

    @PutMapping
    public ResponseEntity<ApiResponse> updateEvidence(@RequestBody Evidence evidence) {
        String result = evidenceService.updateEvidence(evidence);
        return buildResponse(result);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteEvidence(@PathVariable String id) {
        String result = evidenceService.deleteEvidence(id);
        return buildResponse(result);
    }

    @GetMapping("/complaint/{complaintId}")
    public List<Evidence> getEvidenceByComplaintId(@PathVariable String complaintId) {
        return evidenceService.getEvidenceByComplaintId(complaintId);
    }

    private ResponseEntity<ApiResponse> buildResponse(String serviceResult) {
        if (serviceResult == null) {
            return ResponseEntity.internalServerError().body(new ApiResponse(false, "Unknown database error."));
        }
        if (serviceResult.startsWith("Success:")) {
            return ResponseEntity.ok(new ApiResponse(true, serviceResult.replaceFirst("^Success:\\s*", "")));
        } else {
            return ResponseEntity.badRequest().body(new ApiResponse(false, serviceResult.replaceFirst("^Error:\\s*", "")));
        }
    }
}
