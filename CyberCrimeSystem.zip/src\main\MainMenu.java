package main;

import model.Victim;
import model.Officer;
import model.Complaint;
import model.Evidence;
import service.VictimService;
import service.OfficerService;
import service.ComplaintService;
import service.EvidenceService;
import util.MongoDBConnection;
import util.TablePrinter;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Main application class providing a CLI menu for the Cyber Crime Complaint Management System.
 */
public class MainMenu {
    private static final VictimService victimService = new VictimService();
    private static final OfficerService officerService = new OfficerService();
    private static final ComplaintService complaintService = new ComplaintService();
    private static final EvidenceService evidenceService = new EvidenceService();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("==========================================================");
        System.out.println("      CYBER CRIME COMPLAINT MANAGEMENT SYSTEM (CCCMS)     ");
        System.out.println("==========================================================");

        // Attempt initial database check
        if (MongoDBConnection.getDatabase() == null) {
            System.out.println("\n[WARNING] Could not connect to the database on startup.");
            System.out.println("Please start MongoDB and select Option 5 (Database Status) to retry connection.\n");
        }

        boolean exit = false;
        while (!exit) {
            printMainMenu();
            int choice = readInt(scanner, "Enter your choice (1-6): ", 1, 6);
            switch (choice) {
                case 1:
                    handleVictimManagement(scanner);
                    break;
                case 2:
                    handleComplaintManagement(scanner);
                    break;
                case 3:
                    handleOfficerManagement(scanner);
                    break;
                case 4:
                    handleEvidenceManagement(scanner);
                    break;
                case 5:
                    handleSummaryAndReports(scanner);
                    break;
                case 6:
                    exit = true;
                    System.out.println("\nExiting the Cyber Crime Complaint Management System. Goodbye!");
                    MongoDBConnection.closeConnection();
                    break;
            }
        }
        scanner.close();
    }

    private static void printMainMenu() {
        System.out.println("\n===== CYBER CRIME COMPLAINT MANAGEMENT SYSTEM =====");
        System.out.println("1. Victim Management");
        System.out.println("2. Complaint Management");
        System.out.println("3. Officer Management");
        System.out.println("4. Evidence Management");
        System.out.println("5. Summary Reports & Database Status");
        System.out.println("6. Exit");
        System.out.println("===================================================");
    }

    // ==========================================
    // VICTIM MANAGEMENT MODULE
    // ==========================================
    private static void handleVictimManagement(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Victim Management ---");
            System.out.println("1. Add Victim");
            System.out.println("2. View All Victims");
            System.out.println("3. Search Victim by ID");
            System.out.println("4. Update Victim");
            System.out.println("5. Delete Victim");
            System.out.println("6. Back to Main Menu");
            
            int choice = readInt(scanner, "Enter option (1-6): ", 1, 6);
            if (choice == 6) {
                back = true;
                continue;
            }
            if (choice != 2 && MongoDBConnection.getDatabase() == null && !checkDatabaseConnection()) {
                continue;
            }

            switch (choice) {
                case 1: // Add
                    System.out.println("\n[Register New Victim]");
                    String id = readString(scanner, "Enter Victim ID: ", true);
                    String name = readString(scanner, "Enter Name: ", true);
                    int age = readInt(scanner, "Enter Age: ", 1, 120);
                    String gender = readString(scanner, "Enter Gender: ", true);
                    String phone = readString(scanner, "Enter Phone (10 digits): ", true);
                    String email = readString(scanner, "Enter Email: ", true);
                    String address = readString(scanner, "Enter Address: ", true);
                    String city = readString(scanner, "Enter City: ", true);
                    String state = readString(scanner, "Enter State: ", true);

                    Victim victim = new Victim(id, name, age, gender, phone, email, address, city, state);
                    String addRes = victimService.addVictim(victim);
                    printResult(addRes);
                    break;

                case 2: // View All
                    List<Victim> victims = victimService.getAllVictims();
                    displayVictimsTable(victims);
                    break;

                case 3: // Search
                    String sId = readString(scanner, "Enter Victim ID to search: ", true);
                    Victim found = victimService.getVictimById(sId);
                    if (found != null) {
                        List<Victim> singleList = new ArrayList<>();
                        singleList.add(found);
                        displayVictimsTable(singleList);
                    } else {
                        System.out.println("[INFO] No victim found with ID '" + sId + "'.");
                    }
                    break;

                case 4: // Update
                    String uId = readString(scanner, "Enter Victim ID to update: ", true);
                    Victim toUpdate = victimService.getVictimById(uId);
                    if (toUpdate == null) {
                        System.out.println("[ERROR] Victim not found with ID '" + uId + "'.");
                        break;
                    }
                    System.out.println("\nUpdating details for Victim " + uId + " (Leave blank to keep current value):");
                    String uName = readString(scanner, "Name [" + toUpdate.getVictimName() + "]: ", false);
                    String uAgeStr = readString(scanner, "Age [" + toUpdate.getAge() + "]: ", false);
                    String uGender = readString(scanner, "Gender [" + toUpdate.getGender() + "]: ", false);
                    String uPhone = readString(scanner, "Phone [" + toUpdate.getPhone() + "]: ", false);
                    String uEmail = readString(scanner, "Email [" + toUpdate.getEmail() + "]: ", false);
                    String uAddress = readString(scanner, "Address [" + toUpdate.getAddress() + "]: ", false);
                    String uCity = readString(scanner, "City [" + toUpdate.getCity() + "]: ", false);
                    String uState = readString(scanner, "State [" + toUpdate.getState() + "]: ", false);

                    if (!uName.trim().isEmpty()) toUpdate.setVictimName(uName);
                    if (!uAgeStr.trim().isEmpty()) {
                        try {
                            int newAge = Integer.parseInt(uAgeStr.trim());
                            toUpdate.setAge(newAge);
                        } catch (NumberFormatException e) {
                            System.out.println("[WARNING] Invalid age format. Keeping old age value.");
                        }
                    }
                    if (!uGender.trim().isEmpty()) toUpdate.setGender(uGender);
                    if (!uPhone.trim().isEmpty()) toUpdate.setPhone(uPhone);
                    if (!uEmail.trim().isEmpty()) toUpdate.setEmail(uEmail);
                    if (!uAddress.trim().isEmpty()) toUpdate.setAddress(uAddress);
                    if (!uCity.trim().isEmpty()) toUpdate.setCity(uCity);
                    if (!uState.trim().isEmpty()) toUpdate.setState(uState);

                    String updateRes = victimService.updateVictim(toUpdate);
                    printResult(updateRes);
                    break;

                case 5: // Delete
                    String dId = readString(scanner, "Enter Victim ID to delete: ", true);
                    if (confirmAction(scanner, "Are you sure you want to delete victim '" + dId + "'?")) {
                        String delRes = victimService.deleteVictim(dId);
                        printResult(delRes);
                    } else {
                        System.out.println("[INFO] Delete operation cancelled.");
                    }
                    break;
            }
        }
    }

    private static void displayVictimsTable(List<Victim> victims) {
        String[] headers = {"Victim ID", "Name", "Age", "Gender", "Phone", "Email", "City", "State"};
        List<String[]> rows = new ArrayList<>();
        for (Victim v : victims) {
            rows.add(new String[]{
                v.getVictimId(),
                v.getVictimName(),
                String.valueOf(v.getAge()),
                v.getGender(),
                v.getPhone(),
                v.getEmail(),
                v.getCity(),
                v.getState()
            });
        }
        System.out.println("\n--- VICTIM RECORDS ---");
        TablePrinter.printTable(headers, rows);
    }

    // ==========================================
    // COMPLAINT MANAGEMENT MODULE
    // ==========================================
    private static void handleComplaintManagement(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Complaint Management ---");
            System.out.println("1. Register Complaint");
            System.out.println("2. View All Complaints");
            System.out.println("3. Search Complaint by ID");
            System.out.println("4. Update Complaint Status");
            System.out.println("5. Update Complaint Details");
            System.out.println("6. Delete Complaint");
            System.out.println("7. View Complaints by Victim");
            System.out.println("8. View Complaints by Investigating Officer");
            System.out.println("9. Back to Main Menu");

            int choice = readInt(scanner, "Enter option (1-9): ", 1, 9);
            if (choice == 9) {
                back = true;
                continue;
            }
            if (choice != 2 && MongoDBConnection.getDatabase() == null && !checkDatabaseConnection()) {
                continue;
            }

            switch (choice) {
                case 1: // Add
                    System.out.println("\n[Register New Complaint]");
                    String id = readString(scanner, "Enter Complaint ID: ", true);
                    String vId = readString(scanner, "Enter Victim ID: ", true);
                    String oId = readString(scanner, "Enter Assigned Officer ID: ", true);
                    String type = readString(scanner, "Enter Cyber Crime Type: ", true);
                    String desc = readString(scanner, "Enter Complaint Description: ", true);
                    String date = readString(scanner, "Enter Date (YYYY-MM-DD, or leave empty for Today): ", false);
                    String loc = readString(scanner, "Enter Crime Location: ", true);
                    String statusStr = readString(scanner, "Enter Status (Pending/Under Investigation/Resolved) [Default: Pending]: ", false);

                    Complaint complaint = new Complaint(id, vId, oId, type, desc, date, statusStr, loc);
                    String addRes = complaintService.addComplaint(complaint);
                    printResult(addRes);
                    break;

                case 2: // View All
                    List<Complaint> complaints = complaintService.getAllComplaints();
                    displayComplaintsTable(complaints);
                    break;

                case 3: // Search
                    String sId = readString(scanner, "Enter Complaint ID to search: ", true);
                    Complaint found = complaintService.getComplaintById(sId);
                    if (found != null) {
                        List<Complaint> singleList = new ArrayList<>();
                        singleList.add(found);
                        displayComplaintsTable(singleList);
                    } else {
                        System.out.println("[INFO] No complaint found with ID '" + sId + "'.");
                    }
                    break;

                case 4: // Update Status
                    String usId = readString(scanner, "Enter Complaint ID: ", true);
                    String newStatus = readString(scanner, "Enter New Status (Pending/Under Investigation/Resolved): ", true);
                    String statusRes = complaintService.updateComplaintStatus(usId, newStatus);
                    printResult(statusRes);
                    break;

                case 5: // Update Details
                    String uId = readString(scanner, "Enter Complaint ID to update details: ", true);
                    Complaint toUpdate = complaintService.getComplaintById(uId);
                    if (toUpdate == null) {
                        System.out.println("[ERROR] Complaint not found with ID '" + uId + "'.");
                        break;
                    }
                    System.out.println("\nUpdating Complaint details for " + uId + " (Leave blank to keep current):");
                    String uVId = readString(scanner, "Victim ID [" + toUpdate.getVictimId() + "]: ", false);
                    String uOId = readString(scanner, "Officer ID [" + toUpdate.getOfficerId() + "]: ", false);
                    String uType = readString(scanner, "Crime Type [" + toUpdate.getCrimeType() + "]: ", false);
                    String uDesc = readString(scanner, "Description [" + toUpdate.getComplaintDescription() + "]: ", false);
                    String uDate = readString(scanner, "Date [" + toUpdate.getComplaintDate() + "]: ", false);
                    String uLoc = readString(scanner, "Location [" + toUpdate.getLocation() + "]: ", false);

                    if (!uVId.trim().isEmpty()) toUpdate.setVictimId(uVId);
                    if (!uOId.trim().isEmpty()) toUpdate.setOfficerId(uOId);
                    if (!uType.trim().isEmpty()) toUpdate.setCrimeType(uType);
                    if (!uDesc.trim().isEmpty()) toUpdate.setComplaintDescription(uDesc);
                    if (!uDate.trim().isEmpty()) toUpdate.setComplaintDate(uDate);
                    if (!uLoc.trim().isEmpty()) toUpdate.setLocation(uLoc);

                    String updateRes = complaintService.updateComplaint(toUpdate);
                    printResult(updateRes);
                    break;

                case 6: // Delete (Requires Cascade confirmation warning)
                    String dId = readString(scanner, "Enter Complaint ID to delete: ", true);
                    System.out.println("[WARNING] Deleting this complaint will automatically cascade-delete all digital evidence files linked to it.");
                    if (confirmAction(scanner, "Are you sure you want to delete complaint '" + dId + "'?")) {
                        String delRes = complaintService.deleteComplaint(dId);
                        printResult(delRes);
                    } else {
                        System.out.println("[INFO] Delete operation cancelled.");
                    }
                    break;

                case 7: // Filter by Victim
                    String fvId = readString(scanner, "Enter Victim ID: ", true);
                    List<Complaint> victimComplaints = complaintService.getComplaintsByVictimId(fvId);
                    System.out.println("\n--- Complaints Filed by Victim ID: " + fvId + " ---");
                    displayComplaintsTable(victimComplaints);
                    break;

                case 8: // Filter by Officer
                    String foId = readString(scanner, "Enter Officer ID: ", true);
                    List<Complaint> officerComplaints = complaintService.getComplaintsByOfficerId(foId);
                    System.out.println("\n--- Complaints Assigned to Officer ID: " + foId + " ---");
                    displayComplaintsTable(officerComplaints);
                    break;
            }
        }
    }

    private static void displayComplaintsTable(List<Complaint> complaints) {
        String[] headers = {"Complaint ID", "Victim ID", "Officer ID", "Crime Type", "Date", "Status", "Location"};
        List<String[]> rows = new ArrayList<>();
        for (Complaint c : complaints) {
            rows.add(new String[]{
                c.getComplaintId(),
                c.getVictimId(),
                c.getOfficerId(),
                c.getCrimeType(),
                c.getComplaintDate(),
                c.getStatus(),
                c.getLocation()
            });
        }
        System.out.println("\n--- COMPLAINT RECORDS ---");
        TablePrinter.printTable(headers, rows);
    }

    // ==========================================
    // OFFICER MANAGEMENT MODULE
    // ==========================================
    private static void handleOfficerManagement(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Officer Management ---");
            System.out.println("1. Add Officer");
            System.out.println("2. View Officers");
            System.out.println("3. Search Officer by ID");
            System.out.println("4. Update Officer");
            System.out.println("5. Delete Officer");
            System.out.println("6. Back to Main Menu");

            int choice = readInt(scanner, "Enter option (1-6): ", 1, 6);
            if (choice == 6) {
                back = true;
                continue;
            }
            if (choice != 2 && MongoDBConnection.getDatabase() == null && !checkDatabaseConnection()) {
                continue;
            }

            switch (choice) {
                case 1: // Add
                    System.out.println("\n[Register New Investigating Officer]");
                    String id = readString(scanner, "Enter Officer ID: ", true);
                    String name = readString(scanner, "Enter Officer Name: ", true);
                    String rank = readString(scanner, "Enter Rank: ", true);
                    String dept = readString(scanner, "Enter Department: ", true);
                    String phone = readString(scanner, "Enter Phone (10 digits): ", true);
                    String email = readString(scanner, "Enter Email: ", true);

                    Officer officer = new Officer(id, name, rank, dept, phone, email);
                    String addRes = officerService.addOfficer(officer);
                    printResult(addRes);
                    break;

                case 2: // View All
                    List<Officer> officers = officerService.getAllOfficers();
                    displayOfficersTable(officers);
                    break;

                case 3: // Search
                    String sId = readString(scanner, "Enter Officer ID to search: ", true);
                    Officer found = officerService.getOfficerById(sId);
                    if (found != null) {
                        List<Officer> singleList = new ArrayList<>();
                        singleList.add(found);
                        displayOfficersTable(singleList);
                    } else {
                        System.out.println("[INFO] No officer found with ID '" + sId + "'.");
                    }
                    break;

                case 4: // Update
                    String uId = readString(scanner, "Enter Officer ID to update: ", true);
                    Officer toUpdate = officerService.getOfficerById(uId);
                    if (toUpdate == null) {
                        System.out.println("[ERROR] Officer not found with ID '" + uId + "'.");
                        break;
                    }
                    System.out.println("\nUpdating Officer details for " + uId + " (Leave blank to keep current):");
                    String uName = readString(scanner, "Name [" + toUpdate.getOfficerName() + "]: ", false);
                    String uRank = readString(scanner, "Rank [" + toUpdate.getRank() + "]: ", false);
                    String uDept = readString(scanner, "Department [" + toUpdate.getDepartment() + "]: ", false);
                    String uPhone = readString(scanner, "Phone [" + toUpdate.getPhone() + "]: ", false);
                    String uEmail = readString(scanner, "Email [" + toUpdate.getEmail() + "]: ", false);

                    if (!uName.trim().isEmpty()) toUpdate.setOfficerName(uName);
                    if (!uRank.trim().isEmpty()) toUpdate.setRank(uRank);
                    if (!uDept.trim().isEmpty()) toUpdate.setDepartment(uDept);
                    if (!uPhone.trim().isEmpty()) toUpdate.setPhone(uPhone);
                    if (!uEmail.trim().isEmpty()) toUpdate.setEmail(uEmail);

                    String updateRes = officerService.updateOfficer(toUpdate);
                    printResult(updateRes);
                    break;

                case 5: // Delete
                    String dId = readString(scanner, "Enter Officer ID to delete: ", true);
                    if (confirmAction(scanner, "Are you sure you want to delete officer '" + dId + "'?")) {
                        String delRes = officerService.deleteOfficer(dId);
                        printResult(delRes);
                    } else {
                        System.out.println("[INFO] Delete operation cancelled.");
                    }
                    break;
            }
        }
    }

    private static void displayOfficersTable(List<Officer> officers) {
        String[] headers = {"Officer ID", "Name", "Rank", "Department", "Phone", "Email"};
        List<String[]> rows = new ArrayList<>();
        for (Officer o : officers) {
            rows.add(new String[]{
                o.getOfficerId(),
                o.getOfficerName(),
                o.getRank(),
                o.getDepartment(),
                o.getPhone(),
                o.getEmail()
            });
        }
        System.out.println("\n--- INVESTIGATING OFFICERS ---");
        TablePrinter.printTable(headers, rows);
    }

    // ==========================================
    // EVIDENCE MANAGEMENT MODULE
    // ==========================================
    private static void handleEvidenceManagement(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Evidence Management ---");
            System.out.println("1. Add Evidence");
            System.out.println("2. View Evidence");
            System.out.println("3. Search Evidence by ID");
            System.out.println("4. Update Evidence");
            System.out.println("5. Delete Evidence");
            System.out.println("6. View Evidence Linked to Complaint");
            System.out.println("7. Back to Main Menu");

            int choice = readInt(scanner, "Enter option (1-7): ", 1, 7);
            if (choice == 7) {
                back = true;
                continue;
            }
            if (choice != 2 && MongoDBConnection.getDatabase() == null && !checkDatabaseConnection()) {
                continue;
            }

            switch (choice) {
                case 1: // Add
                    System.out.println("\n[Register New Evidence Record]");
                    String id = readString(scanner, "Enter Evidence ID: ", true);
                    String cId = readString(scanner, "Enter Complaint ID: ", true);
                    String type = readString(scanner, "Enter Evidence Type (e.g. IP Log, Disk Dump, Chat History): ", true);
                    String file = readString(scanner, "Enter Evidence Filename: ", true);
                    String desc = readString(scanner, "Enter Description: ", true);
                    String date = readString(scanner, "Enter Date Collected (YYYY-MM-DD, or leave empty for Today): ", false);

                    Evidence evidence = new Evidence(id, cId, type, file, desc, date);
                    String addRes = evidenceService.addEvidence(evidence);
                    printResult(addRes);
                    break;

                case 2: // View All
                    List<Evidence> evidenceList = evidenceService.getAllEvidence();
                    displayEvidenceTable(evidenceList);
                    break;

                case 3: // Search
                    String sId = readString(scanner, "Enter Evidence ID to search: ", true);
                    Evidence found = evidenceService.getEvidenceById(sId);
                    if (found != null) {
                        List<Evidence> singleList = new ArrayList<>();
                        singleList.add(found);
                        displayEvidenceTable(singleList);
                    } else {
                        System.out.println("[INFO] No evidence record found with ID '" + sId + "'.");
                    }
                    break;

                case 4: // Update
                    String uId = readString(scanner, "Enter Evidence ID to update: ", true);
                    Evidence toUpdate = evidenceService.getEvidenceById(uId);
                    if (toUpdate == null) {
                        System.out.println("[ERROR] Evidence record not found with ID '" + uId + "'.");
                        break;
                    }
                    System.out.println("\nUpdating Evidence details for " + uId + " (Leave blank to keep current):");
                    String uCId = readString(scanner, "Complaint ID [" + toUpdate.getComplaintId() + "]: ", false);
                    String uType = readString(scanner, "Evidence Type [" + toUpdate.getEvidenceType() + "]: ", false);
                    String uFile = readString(scanner, "Filename [" + toUpdate.getFileName() + "]: ", false);
                    String uDesc = readString(scanner, "Description [" + toUpdate.getDescription() + "]: ", false);
                    String uDate = readString(scanner, "Date Collected [" + toUpdate.getCollectedDate() + "]: ", false);

                    if (!uCId.trim().isEmpty()) toUpdate.setComplaintId(uCId);
                    if (!uType.trim().isEmpty()) toUpdate.setEvidenceType(uType);
                    if (!uFile.trim().isEmpty()) toUpdate.setFileName(uFile);
                    if (!uDesc.trim().isEmpty()) toUpdate.setDescription(uDesc);
                    if (!uDate.trim().isEmpty()) toUpdate.setCollectedDate(uDate);

                    String updateRes = evidenceService.updateEvidence(toUpdate);
                    printResult(updateRes);
                    break;

                case 5: // Delete
                    String dId = readString(scanner, "Enter Evidence ID to delete: ", true);
                    if (confirmAction(scanner, "Are you sure you want to delete evidence record '" + dId + "'?")) {
                        String delRes = evidenceService.deleteEvidence(dId);
                        printResult(delRes);
                    } else {
                        System.out.println("[INFO] Delete operation cancelled.");
                    }
                    break;

                case 6: // Linked to Complaint
                    String fcId = readString(scanner, "Enter Complaint ID: ", true);
                    List<Evidence> complaintEvidence = evidenceService.getEvidenceByComplaintId(fcId);
                    System.out.println("\n--- Evidence Files Linked to Complaint ID: " + fcId + " ---");
                    displayEvidenceTable(complaintEvidence);
                    break;
            }
        }
    }

    private static void displayEvidenceTable(List<Evidence> evidenceList) {
        String[] headers = {"Evidence ID", "Complaint ID", "Type", "Filename", "Description", "Date Collected"};
        List<String[]> rows = new ArrayList<>();
        for (Evidence e : evidenceList) {
            rows.add(new String[]{
                e.getEvidenceId(),
                e.getComplaintId(),
                e.getEvidenceType(),
                e.getFileName(),
                e.getDescription(),
                e.getCollectedDate()
            });
        }
        System.out.println("\n--- DIGITAL EVIDENCE RECORDS ---");
        TablePrinter.printTable(headers, rows);
    }

    // ==========================================
    // SUMMARY REPORTS MODULE
    // ==========================================
    private static void handleSummaryAndReports(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Summary Reports & Database Status ---");
            System.out.println("1. Generate Counts Summary Report");
            System.out.println("2. Check Database Connection Status");
            System.out.println("3. Retry Database Connection");
            System.out.println("4. Back to Main Menu");

            int choice = readInt(scanner, "Enter option (1-4): ", 1, 4);
            if (choice == 4) {
                back = true;
                continue;
            }

            switch (choice) {
                case 1: // Generate Counts Summary
                    if (MongoDBConnection.getDatabase() == null && !checkDatabaseConnection()) {
                        break;
                    }
                    int vCount = victimService.getAllVictims().size();
                    int cCount = complaintService.getAllComplaints().size();
                    int oCount = officerService.getAllOfficers().size();
                    int eCount = evidenceService.getAllEvidence().size();

                    // Count complaints by status
                    int pendingCount = 0;
                    int activeCount = 0;
                    int resolvedCount = 0;
                    for (Complaint c : complaintService.getAllComplaints()) {
                        if (c.getStatus().equalsIgnoreCase("pending")) pendingCount++;
                        else if (c.getStatus().equalsIgnoreCase("under investigation")) activeCount++;
                        else if (c.getStatus().equalsIgnoreCase("resolved")) resolvedCount++;
                    }

                    System.out.println("\n==============================================");
                    System.out.println("          CCCMS SYSTEM SUMMARY REPORT         ");
                    System.out.println("==============================================");
                    System.out.printf("  Total Victims Registered  : %d\n", vCount);
                    System.out.printf("  Total Officers Recruited  : %d\n", oCount);
                    System.out.printf("  Total Evidence Files      : %d\n", eCount);
                    System.out.printf("  Total Complaints Filed    : %d\n", cCount);
                    System.out.println("  ------------------------------------------");
                    System.out.println("  Complaints Status Breakdown:");
                    System.out.printf("    - Pending               : %d\n", pendingCount);
                    System.out.printf("    - Under Investigation   : %d\n", activeCount);
                    System.out.printf("    - Resolved              : %d\n", resolvedCount);
                    System.out.println("==============================================");
                    break;

                case 2: // Connection Status Check
                    if (MongoDBConnection.getDatabase() != null) {
                        System.out.println("\n[STATUS] Database Status: CONNECTED.");
                        System.out.println("Host: localhost | Port: 27017 | Database: CyberCrimeDB");
                    } else {
                        System.out.println("\n[STATUS] Database Status: DISCONNECTED.");
                    }
                    break;

                case 3: // Retry Connection
                    MongoDBConnection.closeConnection(); // clear previous state
                    if (MongoDBConnection.getDatabase() != null) {
                        System.out.println("[INFO] Connection established successfully!");
                    } else {
                        System.out.println("[ERROR] Failed to reconnect. Make sure MongoDB Community Server service is active.");
                    }
                    break;
            }
        }
    }

    // ==========================================
    // CLI INPUT & DISPLAY HELPERS
    // ==========================================

    private static boolean checkDatabaseConnection() {
        if (MongoDBConnection.getDatabase() == null) {
            System.out.println("\n[ERROR] Database operation failed: No connection to MongoDB.");
            System.out.println("Please start your MongoDB service and choose 'Retry Database Connection' under Option 5.");
            return false;
        }
        return true;
    }

    private static void printResult(String resultMessage) {
        if (resultMessage == null) return;
        if (resultMessage.startsWith("Success")) {
            System.out.println("\n>>> [SUCCESS] " + resultMessage.substring(9));
        } else {
            System.out.println("\n>>> [ERROR] " + resultMessage.substring(6));
        }
    }

    private static String readString(Scanner scanner, String prompt, boolean required) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine();
            if (required && input.trim().isEmpty()) {
                System.out.println("[WARNING] Input is required. Please try again.");
                continue;
            }
            return input;
        }
    }

    private static int readInt(Scanner scanner, String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine();
            try {
                int val = Integer.parseInt(line.trim());
                if (val < min || val > max) {
                    System.out.printf("[WARNING] Input must be between %d and %d. Please try again.\n", min, max);
                    continue;
                }
                return val;
            } catch (NumberFormatException e) {
                System.out.println("[WARNING] Invalid input format. Please enter a valid number.");
            }
        }
    }

    private static boolean confirmAction(Scanner scanner, String question) {
        while (true) {
            System.out.print(question + " (Y/N): ");
            String input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("y") || input.equalsIgnoreCase("yes")) {
                return true;
            }
            if (input.equalsIgnoreCase("n") || input.equalsIgnoreCase("no")) {
                return false;
            }
            System.out.println("[WARNING] Please answer with Y or N.");
        }
    }
}
