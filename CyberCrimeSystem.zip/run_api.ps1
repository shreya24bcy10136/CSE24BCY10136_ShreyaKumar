# run_api.ps1
$ProgressPreference = 'SilentlyContinue'

$projectRoot = $PSScriptRoot
$scratchDir = Split-Path $projectRoot -Parent
$jdkPath = Join-Path $scratchDir "jdk17"

# 1. Ensure local JDK 17 and base driver dependencies exist
Write-Host "Verifying base dependencies..."
& powershell -ExecutionPolicy Bypass -File (Join-Path $projectRoot "download_dependencies.ps1")

# 2. Download local Apache Maven if not present
$mavenDestDir = Join-Path $scratchDir "apache-maven-3.9.6"
$mavenBinPath = Join-Path $mavenDestDir "bin"
$mvnCmd = Join-Path $mavenBinPath "mvn.cmd"

if (-not (Test-Path $mvnCmd)) {
    Write-Host "Local Maven not found. Downloading Apache Maven 3.9.6..."
    $mavenZipPath = Join-Path $scratchDir "maven.zip"
    $mavenUrl = "https://archive.apache.org/dist/maven/maven-3/3.9.6/binaries/apache-maven-3.9.6-bin.zip"
    
    # Download Maven ZIP
    Invoke-WebRequest -Uri $mavenUrl -OutFile $mavenZipPath
    Write-Host "Maven ZIP downloaded successfully. Extracting to $scratchDir..."
    
    # Extract to parent workspace directory (creates 'apache-maven-3.9.6' folder)
    Expand-Archive -Path $mavenZipPath -DestinationPath $scratchDir
    
    # Clean up ZIP
    Remove-Item -Force $mavenZipPath
    Write-Host "Maven set up successfully at $mavenDestDir."
} else {
    Write-Host "Maven is already present at $mavenDestDir."
}

# 3. Configure environment variables for this process
$env:JAVA_HOME = $jdkPath
$env:PATH = "$jdkPath\bin;$mavenBinPath;$env:PATH"
Write-Host "Configured JAVA_HOME to: $env:JAVA_HOME"
Write-Host "Running Java version:"
java -version

# 4. Start Spring Boot REST API
Write-Host "`nStarting Cyber Crime System REST API Server on local port 8080..."
Write-Host "Press Ctrl+C in this terminal to stop the server."
Write-Host "Swagger UI will be available at: http://localhost:8080/swagger-ui/index.html`n"

& "$mvnCmd" spring-boot:run
