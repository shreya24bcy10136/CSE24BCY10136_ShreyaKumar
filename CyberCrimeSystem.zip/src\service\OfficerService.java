package service;

import dao.OfficerDAO;
import dao.ComplaintDAO;
import model.Officer;
import model.Complaint;

import java.util.List;
import java.util.regex.Pattern;

/**
 * Service class for managing Officers, containing business logic and input validation.
 */
public class OfficerService {
    private final OfficerDAO officerDAO = new OfficerDAO();
    private final ComplaintDAO complaintDAO = new ComplaintDAO();

    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\d{10}$");
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");

    /**
     * Validates and adds a new officer.
     */
    public String addOfficer(Officer officer) {
        if (officer.getOfficerId() == null || officer.getOfficerId().trim().isEmpty()) {
            return "Error: Officer ID cannot be empty.";
        }
        if (officer.getOfficerName() == null || officer.getOfficerName().trim().isEmpty()) {
            return "Error: Officer Name cannot be empty.";
        }
        if (officer.getRank() == null || officer.getRank().trim().isEmpty()) {
            return "Error: Rank cannot be empty.";
        }
        if (officer.getDepartment() == null || officer.getDepartment().trim().isEmpty()) {
            return "Error: Department cannot be empty.";
        }
        if (officer.getPhone() == null || !PHONE_PATTERN.matcher(officer.getPhone()).matches()) {
            return "Error: Phone number must be exactly 10 digits.";
        }
        if (officer.getEmail() == null || !EMAIL_PATTERN.matcher(officer.getEmail()).matches()) {
            return "Error: Invalid Email format.";
        }

        // Duplicate ID check
        if (officerDAO.getOfficerById(officer.getOfficerId()) != null) {
            return "Error: Officer ID '" + officer.getOfficerId() + "' already exists.";
        }

        boolean success = officerDAO.addOfficer(officer);
        return success ? "Success: Officer added successfully!" : "Error: Database insertion failed.";
    }

    /**
     * Retrieves all officers.
     */
    public List<Officer> getAllOfficers() {
        return officerDAO.getAllOfficers();
    }

    /**
     * Searches an officer by ID.
     */
    public Officer getOfficerById(String officerId) {
        if (officerId == null || officerId.trim().isEmpty()) {
            return null;
        }
        return officerDAO.getOfficerById(officerId.trim());
    }

    /**
     * Validates and updates an officer's details.
     */
    public String updateOfficer(Officer officer) {
        if (officer.getOfficerId() == null || officer.getOfficerId().trim().isEmpty()) {
            return "Error: Officer ID cannot be empty.";
        }

        // Check if officer exists
        Officer existing = officerDAO.getOfficerById(officer.getOfficerId());
        if (existing == null) {
            return "Error: Officer with ID '" + officer.getOfficerId() + "' not found.";
        }

        if (officer.getOfficerName() == null || officer.getOfficerName().trim().isEmpty()) {
            return "Error: Officer Name cannot be empty.";
        }
        if (officer.getRank() == null || officer.getRank().trim().isEmpty()) {
            return "Error: Rank cannot be empty.";
        }
        if (officer.getDepartment() == null || officer.getDepartment().trim().isEmpty()) {
            return "Error: Department cannot be empty.";
        }
        if (officer.getPhone() == null || !PHONE_PATTERN.matcher(officer.getPhone()).matches()) {
            return "Error: Phone number must be exactly 10 digits.";
        }
        if (officer.getEmail() == null || !EMAIL_PATTERN.matcher(officer.getEmail()).matches()) {
            return "Error: Invalid Email format.";
        }

        boolean success = officerDAO.updateOfficer(officer);
        return success ? "Success: Officer details updated successfully!" : "Error: Database update failed.";
    }

    /**
     * Checks relationships and deletes an officer.
     * Block deletion if they are assigned to complaints.
     */
    public String deleteOfficer(String officerId) {
        if (officerId == null || officerId.trim().isEmpty()) {
            return "Error: Officer ID cannot be empty.";
        }

        Officer officer = officerDAO.getOfficerById(officerId);
        if (officer == null) {
            return "Error: Officer not found with ID '" + officerId + "'.";
        }

        // Relationship Integrity check
        List<Complaint> assignedComplaints = complaintDAO.getComplaintsByOfficerId(officerId);
        if (!assignedComplaints.isEmpty()) {
            return "Error: Cannot delete officer. There are " + assignedComplaints.size() + 
                   " complaint(s) assigned to this officer. Re-assign or resolve those complaints first.";
        }

        boolean success = officerDAO.deleteOfficer(officerId);
        return success ? "Success: Officer record deleted successfully!" : "Error: Database deletion failed.";
    }
}
