# run.ps1
$projectRoot = $PSScriptRoot
$scratchDir = Split-Path $projectRoot -Parent
$jdkPath = Join-Path $scratchDir "jdk17"
$javaCmd = Join-Path $jdkPath "bin\java.exe"
$javacCmd = Join-Path $jdkPath "bin\javac.exe"

# If local JDK 17 isn't found, check if global java is available and is version 17+
if (-not (Test-Path $javacCmd)) {
    Write-Warning "Local JDK 17 not found. Trying system javac..."
    $javacCmd = "javac"
    $javaCmd = "java"
}

# Create bin directory
$binDir = Join-Path $projectRoot "bin"
if (-not (Test-Path $binDir)) {
    New-Item -ItemType Directory -Path $binDir | Out-Null
}

# Find all Java source files
Write-Host "Locating Java source files..."
$javaFiles = Get-ChildItem -Path (Join-Path $projectRoot "src") -Filter "*.java" -Recurse | ForEach-Object { $_.FullName }

if ($javaFiles.Count -eq 0) {
    Write-Error "No Java source files found in src/!"
    exit 1
}

# Write files list to a temp file for javac
$sourcesFile = Join-Path $projectRoot "sources.txt"
$javaFiles | Out-File -FilePath $sourcesFile -Encoding ascii

# Compile
Write-Host "Compiling Java project with JDK 17..."
$classpath = "lib/*;bin"
$compileCmd = "& '$javacCmd' -cp '$classpath' -d '$binDir' @$sourcesFile"
Invoke-Expression $compileCmd

if ($LASTEXITCODE -ne 0) {
    Write-Error "Compilation failed!"
    if (Test-Path $sourcesFile) { Remove-Item -Force $sourcesFile }
    exit 1
}

if (Test-Path $sourcesFile) { Remove-Item -Force $sourcesFile }
Write-Host "Compilation successful!"

# Run main class
Write-Host "Launching Cyber Crime Complaint Management System..."
$runCmd = "& '$javaCmd' -cp '$classpath' main.MainMenu"
Invoke-Expression $runCmd
