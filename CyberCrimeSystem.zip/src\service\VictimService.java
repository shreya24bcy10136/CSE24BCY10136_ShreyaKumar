package service;

import dao.VictimDAO;
import dao.ComplaintDAO;
import model.Victim;
import model.Complaint;

import java.util.List;
import java.util.regex.Pattern;

/**
 * Service class for managing Victims, containing business logic and input validation.
 */
public class VictimService {
    private final VictimDAO victimDAO = new VictimDAO();
    private final ComplaintDAO complaintDAO = new ComplaintDAO();

    // Regex patterns for validation
    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\d{10}$");
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");

    /**
     * Validates and adds a new victim.
     * 
     * @param victim The Victim details.
     * @return String message containing success or specific error details.
     */
    public String addVictim(Victim victim) {
        // Validation checks
        if (victim.getVictimId() == null || victim.getVictimId().trim().isEmpty()) {
            return "Error: Victim ID cannot be empty.";
        }
        if (victim.getVictimName() == null || victim.getVictimName().trim().isEmpty()) {
            return "Error: Victim Name cannot be empty.";
        }
        if (victim.getAge() <= 0 || victim.getAge() > 120) {
            return "Error: Age must be a valid integer between 1 and 120.";
        }
        if (victim.getGender() == null || victim.getGender().trim().isEmpty()) {
            return "Error: Gender cannot be empty.";
        }
        if (victim.getPhone() == null || !PHONE_PATTERN.matcher(victim.getPhone()).matches()) {
            return "Error: Phone number must be exactly 10 digits.";
        }
        if (victim.getEmail() == null || !EMAIL_PATTERN.matcher(victim.getEmail()).matches()) {
            return "Error: Invalid Email format.";
        }

        // Duplicate ID check
        if (victimDAO.getVictimById(victim.getVictimId()) != null) {
            return "Error: Victim ID '" + victim.getVictimId() + "' already exists.";
        }

        boolean success = victimDAO.addVictim(victim);
        return success ? "Success: Victim registered successfully!" : "Error: Database insertion failed.";
    }

    /**
     * Retrieves all victims.
     */
    public List<Victim> getAllVictims() {
        return victimDAO.getAllVictims();
    }

    /**
     * Searches a victim by ID.
     */
    public Victim getVictimById(String victimId) {
        if (victimId == null || victimId.trim().isEmpty()) {
            return null;
        }
        return victimDAO.getVictimById(victimId.trim());
    }

    /**
     * Validates and updates a victim's details.
     */
    public String updateVictim(Victim victim) {
        if (victim.getVictimId() == null || victim.getVictimId().trim().isEmpty()) {
            return "Error: Victim ID cannot be empty.";
        }
        
        // Check if victim exists
        Victim existing = victimDAO.getVictimById(victim.getVictimId());
        if (existing == null) {
            return "Error: Victim with ID '" + victim.getVictimId() + "' not found.";
        }

        if (victim.getVictimName() == null || victim.getVictimName().trim().isEmpty()) {
            return "Error: Victim Name cannot be empty.";
        }
        if (victim.getAge() <= 0 || victim.getAge() > 120) {
            return "Error: Age must be a valid integer between 1 and 120.";
        }
        if (victim.getGender() == null || victim.getGender().trim().isEmpty()) {
            return "Error: Gender cannot be empty.";
        }
        if (victim.getPhone() == null || !PHONE_PATTERN.matcher(victim.getPhone()).matches()) {
            return "Error: Phone number must be exactly 10 digits.";
        }
        if (victim.getEmail() == null || !EMAIL_PATTERN.matcher(victim.getEmail()).matches()) {
            return "Error: Invalid Email format.";
        }

        boolean success = victimDAO.updateVictim(victim);
        return success ? "Success: Victim details updated successfully!" : "Error: Database update failed.";
    }

    /**
     * Checks relationships and deletes a victim.
     * Block deletion if they are associated with complaints.
     */
    public String deleteVictim(String victimId) {
        if (victimId == null || victimId.trim().isEmpty()) {
            return "Error: Victim ID cannot be empty.";
        }

        Victim victim = victimDAO.getVictimById(victimId);
        if (victim == null) {
            return "Error: Victim not found with ID '" + victimId + "'.";
        }

        // Relationship Integrity check
        List<Complaint> associatedComplaints = complaintDAO.getComplaintsByVictimId(victimId);
        if (!associatedComplaints.isEmpty()) {
            return "Error: Cannot delete victim. There are " + associatedComplaints.size() + 
                   " complaint(s) linked to this victim. Delete those complaints first.";
        }

        boolean success = victimDAO.deleteVictim(victimId);
        return success ? "Success: Victim record deleted successfully!" : "Error: Database deletion failed.";
    }
}
