package util;

import com.mongodb.MongoException;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import java.util.ArrayList;
import java.util.List;

/**
 * Singleton class to manage MongoDB connection.
 */
public class MongoDBConnection {
    private static final String CONNECTION_URI = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "CyberCrimeDB";
    
    private static MongoClient mongoClient = null;
    private static MongoDatabase database = null;

    // List of collections that should exist in the database
    private static final String[] COLLECTIONS = {"victims", "officers", "complaints", "evidence"};

    // Private constructor to prevent instantiation
    private MongoDBConnection() {}

    /**
     * Retrieves the MongoDatabase instance, establishing connection if not already created.
     * Checks and creates collections automatically if they do not exist.
     * 
     * @return MongoDatabase instance or null if connection fails.
     */
    public static synchronized MongoDatabase getDatabase() {
        if (database == null) {
            try {
                System.out.println("Connecting to MongoDB at " + CONNECTION_URI + "...");
                mongoClient = MongoClients.create(CONNECTION_URI);
                database = mongoClient.getDatabase(DATABASE_NAME);
                
                // Trigger a lightweight command to force connection verification
                database.runCommand(new org.bson.Document("ping", 1));
                System.out.println("Database connection established successfully!");

                // Check and create collections automatically if they do not exist
                initializeCollections();
                
            } catch (MongoException e) {
                System.err.println("\n[ERROR] Database Connection Failed!");
                System.err.println("Ensure that MongoDB Community Server is installed and running locally on port 27017.");
                System.err.println("Details: " + e.getMessage() + "\n");
                database = null;
                if (mongoClient != null) {
                    mongoClient.close();
                    mongoClient = null;
                }
            } catch (Exception e) {
                System.err.println("\n[ERROR] An unexpected error occurred while connecting to database!");
                System.err.println("Details: " + e.getMessage() + "\n");
                database = null;
            }
        }
        return database;
    }

    /**
     * Helper method to verify and automatically create collections.
     */
    private static void initializeCollections() {
        if (database == null) return;
        
        try {
            // Retrieve existing collection names
            List<String> existingCollections = database.listCollectionNames().into(new ArrayList<>());
            
            for (String colName : COLLECTIONS) {
                if (!existingCollections.contains(colName)) {
                    database.createCollection(colName);
                    System.out.println("Created collection: " + colName);
                }
            }
            
            // Auto-seed mock data if empty
            seedData();
        } catch (Exception e) {
            System.err.println("[ERROR] Failed to auto-initialize collections: " + e.getMessage());
        }
    }

    /**
     * Seeds realistic mock data if the database collections are currently empty.
     */
    private static void seedData() {
        if (database == null) return;

        try {
            MongoCollection<Document> victimsCol = database.getCollection("victims");
            MongoCollection<Document> officersCol = database.getCollection("officers");
            MongoCollection<Document> complaintsCol = database.getCollection("complaints");
            MongoCollection<Document> evidenceCol = database.getCollection("evidence");

            // 1. Seed Victims if empty
            if (victimsCol.countDocuments() == 0) {
                System.out.println("Seeding mock data for 'victims' collection...");
                List<Document> victims = new ArrayList<>();
                victims.add(new Document("victimId", "VIC-101")
                        .append("victimName", "Sarah Jenkins")
                        .append("age", 34)
                        .append("gender", "Female")
                        .append("phone", "9876543210")
                        .append("email", "sarah.j@email.com")
                        .append("address", "742 Evergreen Terrace")
                        .append("city", "Springfield")
                        .append("state", "Illinois"));
                victims.add(new Document("victimId", "VIC-102")
                        .append("victimName", "Alex Rivera")
                        .append("age", 28)
                        .append("gender", "Male")
                        .append("phone", "9123456780")
                        .append("email", "alex.rivera@email.com")
                        .append("address", "12 Pine Street")
                        .append("city", "Metro City")
                        .append("state", "New York"));
                victims.add(new Document("victimId", "VIC-103")
                        .append("victimName", "Priya Sharma")
                        .append("age", 45)
                        .append("gender", "Female")
                        .append("phone", "9988776655")
                        .append("email", "priya.s@email.com")
                        .append("address", "404 Main Boulevard")
                        .append("city", "Tech City")
                        .append("state", "California"));
                victimsCol.insertMany(victims);
                System.out.println("Successfully seeded 3 victims.");
            }

            // 2. Seed Officers if empty
            if (officersCol.countDocuments() == 0) {
                System.out.println("Seeding mock data for 'officers' collection...");
                List<Document> officers = new ArrayList<>();
                officers.add(new Document("officerId", "OFC-101")
                        .append("officerName", "Inspector James Gordon")
                        .append("rank", "Senior Inspector")
                        .append("department", "Cyber Patrol & Intelligence")
                        .append("phone", "9812738291")
                        .append("email", "gordon@police.gov"));
                officers.add(new Document("officerId", "OFC-102")
                        .append("officerName", "Agent Diana Prince")
                        .append("rank", "Special Agent")
                        .append("department", "Digital Forensics Lab")
                        .append("phone", "9765432109")
                        .append("email", "diana.prince@police.gov"));
                officers.add(new Document("officerId", "OFC-103")
                        .append("officerName", "Sergeant Marcus Burnett")
                        .append("rank", "Sergeant")
                        .append("department", "Cyber Fraud Investigation")
                        .append("phone", "9654321098")
                        .append("email", "marcus.b@police.gov"));
                officersCol.insertMany(officers);
                System.out.println("Successfully seeded 3 officers.");
            }

            // 3. Seed Complaints if empty
            if (complaintsCol.countDocuments() == 0) {
                System.out.println("Seeding mock data for 'complaints' collection...");
                List<Document> complaints = new ArrayList<>();
                complaints.add(new Document("complaintId", "CMP-201")
                        .append("victimId", "VIC-101")
                        .append("officerId", "OFC-101")
                        .append("crimeType", "Identity Theft & Phishing")
                        .append("complaintDescription", "Victim received a spoofed bank alert and logged in, resulting in unauthorized transfers of $5,000.")
                        .append("complaintDate", "2026-06-10")
                        .append("status", "Under Investigation")
                        .append("location", "Springfield Branch Online Portal"));
                complaints.add(new Document("complaintId", "CMP-202")
                        .append("victimId", "VIC-102")
                        .append("officerId", "OFC-102")
                        .append("crimeType", "Ransomware Attack")
                        .append("complaintDescription", "Personal laptop files encrypted with .lock extension. Hacker demanding 0.1 BTC.")
                        .append("complaintDate", "2026-06-12")
                        .append("status", "Pending")
                        .append("location", "Home Network"));
                complaints.add(new Document("complaintId", "CMP-203")
                        .append("victimId", "VIC-103")
                        .append("officerId", "OFC-103")
                        .append("crimeType", "Social Media Hacking")
                        .append("complaintDescription", "Business Instagram and email accounts hacked and used for selling fake crypto investment schemes.")
                        .append("complaintDate", "2026-06-14")
                        .append("status", "Resolved")
                        .append("location", "Instagram Platform"));
                complaintsCol.insertMany(complaints);
                System.out.println("Successfully seeded 3 complaints.");
            }

            // 4. Seed Evidence if empty
            if (evidenceCol.countDocuments() == 0) {
                System.out.println("Seeding mock data for 'evidence' collection...");
                List<Document> evidences = new ArrayList<>();
                evidences.add(new Document("evidenceId", "EVD-301")
                        .append("complaintId", "CMP-201")
                        .append("evidenceType", "Email Headers")
                        .append("fileName", "phishing_email_headers.txt")
                        .append("description", "Email headers containing spoofed address and IP of originating SMTP server.")
                        .append("collectedDate", "2026-06-11"));
                evidences.add(new Document("evidenceId", "EVD-302")
                        .append("complaintId", "CMP-201")
                        .append("evidenceType", "Web Server Log")
                        .append("fileName", "redirect_logs.csv")
                        .append("description", "Web history redirecting to server registered in Eastern Europe.")
                        .append("collectedDate", "2026-06-11"));
                evidences.add(new Document("evidenceId", "EVD-303")
                        .append("complaintId", "CMP-202")
                        .append("evidenceType", "Ransom Note")
                        .append("fileName", "READ_ME_FOR_DECRYPT.txt")
                        .append("description", "Text file ransom note left on victim desktop with instructions.")
                        .append("collectedDate", "2026-06-13"));
                evidences.add(new Document("evidenceId", "EVD-304")
                        .append("complaintId", "CMP-203")
                        .append("evidenceType", "IP Login Log")
                        .append("fileName", "instagram_login_history.json")
                        .append("description", "Exported meta login history showing unrecognized IP logins from outside the state.")
                        .append("collectedDate", "2026-06-15"));
                evidenceCol.insertMany(evidences);
                System.out.println("Successfully seeded 4 evidence records.");
            }

        } catch (Exception e) {
            System.err.println("[ERROR] Failed to seed mock data: " + e.getMessage());
        }
    }

    /**
     * Closes the MongoClient connection.
     */
    public static synchronized void closeConnection() {
        if (mongoClient != null) {
            try {
                mongoClient.close();
                System.out.println("Database connection closed.");
            } catch (Exception e) {
                System.err.println("Error closing database connection: " + e.getMessage());
            } finally {
                mongoClient = null;
                database = null;
            }
        }
    }
}
