package dao;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import model.Officer;
import org.bson.Document;
import org.bson.conversions.Bson;
import util.MongoDBConnection;

import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Officer entity.
 */
public class OfficerDAO {
    private static final String COLLECTION_NAME = "officers";

    private MongoCollection<Document> getCollection() {
        MongoDatabase db = MongoDBConnection.getDatabase();
        if (db == null) {
            throw new RuntimeException("Database connection is not available.");
        }
        return db.getCollection(COLLECTION_NAME);
    }

    private Document officerToDocument(Officer o) {
        return new Document("officerId", o.getOfficerId())
                .append("officerName", o.getOfficerName())
                .append("rank", o.getRank())
                .append("department", o.getDepartment())
                .append("phone", o.getPhone())
                .append("email", o.getEmail());
    }

    private Officer documentToOfficer(Document doc) {
        if (doc == null) return null;
        return new Officer(
                doc.getString("officerId"),
                doc.getString("officerName"),
                doc.getString("rank"),
                doc.getString("department"),
                doc.getString("phone"),
                doc.getString("email")
        );
    }

    public boolean addOfficer(Officer officer) {
        try {
            getCollection().insertOne(officerToDocument(officer));
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to add officer: " + e.getMessage());
            return false;
        }
    }

    public List<Officer> getAllOfficers() {
        List<Officer> officers = new ArrayList<>();
        try {
            for (Document doc : getCollection().find()) {
                officers.add(documentToOfficer(doc));
            }
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to retrieve officers: " + e.getMessage());
        }
        return officers;
    }

    public Officer getOfficerById(String officerId) {
        try {
            Document doc = getCollection().find(Filters.eq("officerId", officerId)).first();
            return documentToOfficer(doc);
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to find officer by ID: " + e.getMessage());
            return null;
        }
    }

    public boolean updateOfficer(Officer officer) {
        try {
            Bson filter = Filters.eq("officerId", officer.getOfficerId());
            Bson updates = Updates.combine(
                    Updates.set("officerName", officer.getOfficerName()),
                    Updates.set("rank", officer.getRank()),
                    Updates.set("department", officer.getDepartment()),
                    Updates.set("phone", officer.getPhone()),
                    Updates.set("email", officer.getEmail())
            );
            getCollection().updateOne(filter, updates);
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to update officer: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteOfficer(String officerId) {
        try {
            getCollection().deleteOne(Filters.eq("officerId", officerId));
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to delete officer: " + e.getMessage());
            return false;
        }
    }
}
