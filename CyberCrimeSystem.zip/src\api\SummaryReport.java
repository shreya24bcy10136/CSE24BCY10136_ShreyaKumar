package api;

import java.util.Map;

/**
 * Model class representing database summary statistics and status.
 */
public class SummaryReport {
    private int totalVictims;
    private int totalOfficers;
    private int totalEvidence;
    private int totalComplaints;
    private Map<String, Integer> complaintStatusBreakdown;
    private boolean databaseConnected;

    public SummaryReport() {}

    public SummaryReport(int totalVictims, int totalOfficers, int totalEvidence, int totalComplaints,
                         Map<String, Integer> complaintStatusBreakdown, boolean databaseConnected) {
        this.totalVictims = totalVictims;
        this.totalOfficers = totalOfficers;
        this.totalEvidence = totalEvidence;
        this.totalComplaints = totalComplaints;
        this.complaintStatusBreakdown = complaintStatusBreakdown;
        this.databaseConnected = databaseConnected;
    }

    public int getTotalVictims() {
        return totalVictims;
    }

    public void setTotalVictims(int totalVictims) {
        this.totalVictims = totalVictims;
    }

    public int getTotalOfficers() {
        return totalOfficers;
    }

    public void setTotalOfficers(int totalOfficers) {
        this.totalOfficers = totalOfficers;
    }

    public int getTotalEvidence() {
        return totalEvidence;
    }

    public void setTotalEvidence(int totalEvidence) {
        this.totalEvidence = totalEvidence;
    }

    public int getTotalComplaints() {
        return totalComplaints;
    }

    public void setTotalComplaints(int totalComplaints) {
        this.totalComplaints = totalComplaints;
    }

    public Map<String, Integer> getComplaintStatusBreakdown() {
        return complaintStatusBreakdown;
    }

    public void setComplaintStatusBreakdown(Map<String, Integer> complaintStatusBreakdown) {
        this.complaintStatusBreakdown = complaintStatusBreakdown;
    }

    public boolean isDatabaseConnected() {
        return databaseConnected;
    }

    public void setDatabaseConnected(boolean databaseConnected) {
        this.databaseConnected = databaseConnected;
    }
}
