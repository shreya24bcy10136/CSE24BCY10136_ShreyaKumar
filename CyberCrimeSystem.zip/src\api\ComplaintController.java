package api;

import model.Complaint;
import service.ComplaintService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Controller exposing Complaint Management REST APIs.
 */
@RestController
@RequestMapping("/api/complaints")
@Tag(name = "Complaint Management", description = "CRUD and query operations for cyber crime complaints")
public class ComplaintController {
    private final ComplaintService complaintService = new ComplaintService();

    @GetMapping
    public List<Complaint> getAllComplaints() {
        return complaintService.getAllComplaints();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Complaint> getComplaintById(@PathVariable String id) {
        Complaint complaint = complaintService.getComplaintById(id);
        if (complaint == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(complaint);
    }

    @PostMapping
    public ResponseEntity<ApiResponse> addComplaint(@RequestBody Complaint complaint) {
        String result = complaintService.addComplaint(complaint);
        return buildResponse(result);
    }

    @PutMapping
    public ResponseEntity<ApiResponse> updateComplaint(@RequestBody Complaint complaint) {
        String result = complaintService.updateComplaint(complaint);
        return buildResponse(result);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<ApiResponse> updateComplaintStatus(
            @PathVariable String id, 
            @RequestParam String status) {
        String result = complaintService.updateComplaintStatus(id, status);
        return buildResponse(result);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteComplaint(@PathVariable String id) {
        String result = complaintService.deleteComplaint(id);
        return buildResponse(result);
    }

    @GetMapping("/victim/{victimId}")
    public List<Complaint> getComplaintsByVictimId(@PathVariable String victimId) {
        return complaintService.getComplaintsByVictimId(victimId);
    }

    @GetMapping("/officer/{officerId}")
    public List<Complaint> getComplaintsByOfficerId(@PathVariable String officerId) {
        return complaintService.getComplaintsByOfficerId(officerId);
    }

    private ResponseEntity<ApiResponse> buildResponse(String serviceResult) {
        if (serviceResult == null) {
            return ResponseEntity.internalServerError().body(new ApiResponse(false, "Unknown database error."));
        }
        if (serviceResult.startsWith("Success:")) {
            return ResponseEntity.ok(new ApiResponse(true, serviceResult.replaceFirst("^Success:\\s*", "")));
        } else {
            return ResponseEntity.badRequest().body(new ApiResponse(false, serviceResult.replaceFirst("^Error:\\s*", "")));
        }
    }
}
