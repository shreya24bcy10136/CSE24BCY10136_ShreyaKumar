# 🛡️ Cyber Crime Complaint Management System (CCCMS)

A robust, enterprise-grade management system designed to track, investigate, and audit cybercrime complaints. The system offers a **Dual-Interface** implementation: a **Spring Boot REST API** with interactive OpenAPI/Swagger documentation, and an **Interactive Console-based Command Line Interface (CLI)**.

---

## 🛠️ Tech Stack & Frameworks

The system is built using modern, stable Java enterprise technologies:

| Component | Technology | Version / Details |
| :--- | :--- | :--- |
| **Language Runtime** | **Java SE (JDK)** | Version `17` (Eclipse Temurin) |
| **Web Framework** | **Spring Boot** | Version `3.2.5` |
| **REST Documentation** | **Springdoc OpenAPI / Swagger UI** | Version `2.5.0` |
| **Database** | **MongoDB** | Community Server (v4.11.1 Sync Driver) |
| **Build System** | **Apache Maven** | Version `3.9.6` |
| **Automation** | **PowerShell** | Custom run & dependency resolution scripts |

---

## 🚀 Key Features

1. **Victim Management**: Complete lifecycle registry of victims, capturing contact information, demographic details, and address records.
2. **Investigating Officer Registry**: Directory of law enforcement agents, their departments, ranks, and contact details.
3. **Complaint Tracking**: Detailed logging of cybercrime instances, linking victims to investigating officers. Tracks status updates (`Pending`, `Under Investigation`, `Resolved`), location, and timestamps.
4. **Digital Evidence Locker**: Safe repository links for digital evidence (logs, disk dumps, chat files) tied directly to specific complaints.
5. **Data Integrity Guards**:
   - **Cascade Deletion**: Deleting a complaint automatically cleans up all associated digital evidence to prevent orphaned records.
   - **Deletion Blocker**: Restricts deletion of victims or officers who are currently linked to active, unresolved complaints.
6. **Programmatic System Verification**: A self-contained validation runner that automatically executes integration tests for connection status, CRUD, and data constraint rules.

---

## ⚙️ Prerequisites & Setup

Ensure the following are configured before launching the application:

1. **Operating System**: Windows OS (to execute the provided PowerShell wrapper scripts).
2. **Database Service**: MongoDB Community Server installed and running locally on standard port `27017` (No authentication required by default).
   - *Database Name*: `CyberCrimeDB`
   - *Collections*: `victims`, `officers`, `complaints`, `evidence` (all automatically initialized on application startup).

---

## 🏃 Instructions on How to Run

The application provides fully automated scripts to resolve dependencies (JDK, Maven, database drivers) and run the system without manual environment configuration.

### 1. Launching the Spring Boot REST API
Run the following script in a PowerShell terminal:
```powershell
.\run_api.ps1
```
* **What this does**: Automatically downloads Adoptium JDK 17 & Apache Maven 3.9.6 (if not already present in the parent folder), resolves dependency JARs, starts the Spring Boot web server on port `8080`, and hosts the REST API.
* **Accessing the API Docs**: Open your browser and navigate to:
  👉 **[http://localhost:8080/swagger-ui/index.html](http://localhost:8080/swagger-ui/index.html)**

### 2. Launching the Console CLI Application
Run the following script in a PowerShell terminal:
```powershell
.\run.ps1
```
* **What this does**: Compiles all Java source code inside the `src` folder with the classpath set to include all dependency JARs inside the `lib` folder, then boots up the interactive menu interface.

### 3. Running the Verification Test Suite
To execute the suite of programmatic integration tests verifying database connectivity, cascade deletions, and relational integrity guards:
```powershell
# In PowerShell, configure the java executable path to run the VerificationTest main method
& ..\jdk17\bin\java.exe -cp "lib/*;bin" main.VerificationTest
```
*(If local JDK is not installed in the parent folder, you can run `java -cp "lib/*;bin" main.VerificationTest` using your global system JDK 17 environment).*

---

## 📸 System Screenshots

Here is a visual walk-through of the interactive Swagger UI REST API endpoints:

### 1. Swagger UI Main Dashboard & Schemas
Overview of the OpenAPI 3 documentation interface, displaying controllers for Officer, Evidence, Victim, Summary, and Complaint Management, alongside BSON mapping schemas.
![Swagger UI Overview](screenshots/screenshot1.png)

### 2. Officer Management API Endpoints
Visual listing of the CRUD endpoints available within the Officer Management module (GET, POST, PUT, DELETE).
![Officer Endpoints](screenshots/screenshot2.png)

### 3. Querying Seeded Officers (GET /api/officers)
Swagger UI response showing the retrieval of the 3 pre-seeded investigating officers (Inspector Gordon, Agent Prince, and Sergeant Burnett) directly from MongoDB.
![GET Seeded Officers](screenshots/screenshot3.png)

### 4. Swagger PUT Request Interface
Interactive interface showing the JSON structure template for updating details of an existing investigating officer.
![PUT Request Interface](screenshots/screenshot4.png)

### 5. Swagger POST Request Interface
Interactive interface showing the JSON structure template for registering a new investigating officer.
![POST Request Interface](screenshots/screenshot5.png)

### 6. Querying Seeded Evidence (GET /api/evidence)
Shows Swagger UI retrieving the 4 pre-seeded digital evidence logs and files from the database.
![GET Seeded Evidence](screenshots/screenshot6.png)

### 7. Swagger Evidence PUT Template
Displays the JSON schema payload for editing details of registered digital evidence records.
![PUT Evidence Interface](screenshots/screenshot7.png)

### 8. Querying Seeded Victims (GET /api/victims)
Shows Swagger UI retrieving the 3 pre-seeded victim registration records from the database.
![GET Seeded Victims](screenshots/screenshot8.png)

### 9. Swagger Victim PUT Template
Displays the JSON schema payload for editing details of registered victims.
![PUT Victim Interface](screenshots/screenshot9.png)

### 10. Swagger Victim POST Template
Displays the JSON schema payload for registering a new victim in the system.
![POST Victim Interface](screenshots/screenshot10.png)

### 11. System Summary Statistics (GET /api/summary)
Displays Swagger UI retrieving database connection status, counts of registered victims, officers, complaints, and evidence, and the complaint status breakdowns.
![GET System Summary](screenshots/screenshot11.png)

### 12. Querying Seeded Complaints (GET /api/complaints)
Shows Swagger UI retrieving the 3 pre-seeded complaints in full detail from MongoDB.
![GET Seeded Complaints](screenshots/screenshot12.png)

### 13. Swagger Complaint PUT Template
Displays the JSON schema payload for editing details of registered complaints.
![PUT Complaint Interface](screenshots/screenshot13.png)

### 14. Swagger Complaint POST Template
Displays the JSON schema payload for registering a new complaint in the system.
![POST Complaint Interface](screenshots/screenshot14.png)

### 15. Filtering Complaints by Victim (GET /api/complaints/victim/{victimId})
Shows Swagger UI filtering and retrieving complaints associated with a specific victim ID (e.g., `VIC-101`).
![GET Complaints by Victim](screenshots/screenshot15.png)

### 16. Filtering Complaints by Officer (GET /api/complaints/officer/{officerId})
Shows Swagger UI filtering and retrieving complaints assigned to a specific investigating officer ID (e.g., `OFC-102`).
![GET Complaints by Officer](screenshots/screenshot16.png)
