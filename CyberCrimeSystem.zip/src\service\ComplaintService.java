package service;

import dao.ComplaintDAO;
import dao.VictimDAO;
import dao.OfficerDAO;
import dao.EvidenceDAO;
import model.Complaint;
import model.Evidence;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

/**
 * Service class for managing Complaints, validating dependencies (Victims, Officers) and cascading deletions.
 */
public class ComplaintService {
    private final ComplaintDAO complaintDAO = new ComplaintDAO();
    private final VictimDAO victimDAO = new VictimDAO();
    private final OfficerDAO officerDAO = new OfficerDAO();
    private final EvidenceDAO evidenceDAO = new EvidenceDAO();

    private static final List<String> VALID_STATUSES = Arrays.asList("Pending", "Under Investigation", "Resolved");

    /**
     * Validates and registers a new complaint.
     */
    public String addComplaint(Complaint complaint) {
        if (complaint.getComplaintId() == null || complaint.getComplaintId().trim().isEmpty()) {
            return "Error: Complaint ID cannot be empty.";
        }
        if (complaint.getCrimeType() == null || complaint.getCrimeType().trim().isEmpty()) {
            return "Error: Crime Type cannot be empty.";
        }
        if (complaint.getComplaintDescription() == null || complaint.getComplaintDescription().trim().isEmpty()) {
            return "Error: Description cannot be empty.";
        }
        if (complaint.getLocation() == null || complaint.getLocation().trim().isEmpty()) {
            return "Error: Location cannot be empty.";
        }

        // Duplicate ID check
        if (complaintDAO.getComplaintById(complaint.getComplaintId()) != null) {
            return "Error: Complaint ID '" + complaint.getComplaintId() + "' already exists.";
        }

        // Referential Integrity check: Victim
        if (complaint.getVictimId() == null || victimDAO.getVictimById(complaint.getVictimId()) == null) {
            return "Error: Referenced Victim ID '" + complaint.getVictimId() + "' does not exist.";
        }

        // Referential Integrity check: Officer
        if (complaint.getOfficerId() == null || officerDAO.getOfficerById(complaint.getOfficerId()) == null) {
            return "Error: Referenced Officer ID '" + complaint.getOfficerId() + "' does not exist.";
        }

        // Default complaint date to current date if empty/null
        if (complaint.getComplaintDate() == null || complaint.getComplaintDate().trim().isEmpty()) {
            complaint.setComplaintDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        }

        // Validate or default Status
        if (complaint.getStatus() == null || complaint.getStatus().trim().isEmpty()) {
            complaint.setStatus("Pending");
        } else {
            String status = capitalizeStatus(complaint.getStatus().trim());
            if (!VALID_STATUSES.contains(status)) {
                return "Error: Invalid status. Must be one of: " + VALID_STATUSES;
            }
            complaint.setStatus(status);
        }

        boolean success = complaintDAO.addComplaint(complaint);
        return success ? "Success: Complaint registered successfully!" : "Error: Database insertion failed.";
    }

    /**
     * Retrieves all complaints.
     */
    public List<Complaint> getAllComplaints() {
        return complaintDAO.getAllComplaints();
    }

    /**
     * Searches a complaint by ID.
     */
    public Complaint getComplaintById(String complaintId) {
        if (complaintId == null || complaintId.trim().isEmpty()) {
            return null;
        }
        return complaintDAO.getComplaintById(complaintId.trim());
    }

    /**
     * Updates complaint details (excluding status, which has its own menu option).
     */
    public String updateComplaint(Complaint complaint) {
        if (complaint.getComplaintId() == null || complaint.getComplaintId().trim().isEmpty()) {
            return "Error: Complaint ID cannot be empty.";
        }

        Complaint existing = complaintDAO.getComplaintById(complaint.getComplaintId());
        if (existing == null) {
            return "Error: Complaint with ID '" + complaint.getComplaintId() + "' not found.";
        }

        if (complaint.getCrimeType() == null || complaint.getCrimeType().trim().isEmpty()) {
            return "Error: Crime Type cannot be empty.";
        }
        if (complaint.getComplaintDescription() == null || complaint.getComplaintDescription().trim().isEmpty()) {
            return "Error: Description cannot be empty.";
        }
        if (complaint.getLocation() == null || complaint.getLocation().trim().isEmpty()) {
            return "Error: Location cannot be empty.";
        }

        // Validate referencing Victim ID
        if (complaint.getVictimId() == null || victimDAO.getVictimById(complaint.getVictimId()) == null) {
            return "Error: Referenced Victim ID '" + complaint.getVictimId() + "' does not exist.";
        }

        // Validate referencing Officer ID
        if (complaint.getOfficerId() == null || officerDAO.getOfficerById(complaint.getOfficerId()) == null) {
            return "Error: Referenced Officer ID '" + complaint.getOfficerId() + "' does not exist.";
        }

        // Preserve status and date if not provided in update payload
        if (complaint.getComplaintDate() == null || complaint.getComplaintDate().trim().isEmpty()) {
            complaint.setComplaintDate(existing.getComplaintDate());
        }

        boolean success = complaintDAO.updateComplaint(complaint);
        return success ? "Success: Complaint details updated successfully!" : "Error: Database update failed.";
    }

    /**
     * Updates only the status of the complaint.
     */
    public String updateComplaintStatus(String complaintId, String newStatus) {
        if (complaintId == null || complaintId.trim().isEmpty()) {
            return "Error: Complaint ID cannot be empty.";
        }
        if (newStatus == null || newStatus.trim().isEmpty()) {
            return "Error: Status cannot be empty.";
        }

        Complaint existing = complaintDAO.getComplaintById(complaintId);
        if (existing == null) {
            return "Error: Complaint with ID '" + complaintId + "' not found.";
        }

        String status = capitalizeStatus(newStatus.trim());
        if (!VALID_STATUSES.contains(status)) {
            return "Error: Invalid status. Must be one of: " + VALID_STATUSES;
        }

        boolean success = complaintDAO.updateComplaintStatus(complaintId, status);
        return success ? "Success: Complaint status updated to '" + status + "' successfully!" : "Error: Database status update failed.";
    }

    /**
     * Deletes a complaint and cascade deletes all linked evidence.
     */
    public String deleteComplaint(String complaintId) {
        if (complaintId == null || complaintId.trim().isEmpty()) {
            return "Error: Complaint ID cannot be empty.";
        }

        Complaint existing = complaintDAO.getComplaintById(complaintId);
        if (existing == null) {
            return "Error: Complaint not found with ID '" + complaintId + "'.";
        }

        // 1. Check for linked evidence
        List<Evidence> linkedEvidence = evidenceDAO.getEvidenceByComplaintId(complaintId);
        int evidenceCount = linkedEvidence.size();

        // 2. Cascade delete evidence records
        if (evidenceCount > 0) {
            boolean evidenceDeleted = evidenceDAO.deleteEvidenceByComplaintId(complaintId);
            if (!evidenceDeleted) {
                return "Error: Failed to clear associated evidence records. Aborting complaint deletion.";
            }
        }

        // 3. Delete complaint record
        boolean success = complaintDAO.deleteComplaint(complaintId);
        if (success) {
            return "Success: Complaint record deleted successfully!" + 
                   (evidenceCount > 0 ? " (Cascade deleted " + evidenceCount + " associated evidence record(s).)" : "");
        } else {
            return "Error: Database deletion failed.";
        }
    }

    /**
     * Helper to retrieve complaints by Victim ID.
     */
    public List<Complaint> getComplaintsByVictimId(String victimId) {
        return complaintDAO.getComplaintsByVictimId(victimId);
    }

    /**
     * Helper to retrieve complaints by Officer ID.
     */
    public List<Complaint> getComplaintsByOfficerId(String officerId) {
        return complaintDAO.getComplaintsByOfficerId(officerId);
    }

    /**
     * Capitalizes standard status inputs for consistency.
     */
    private String capitalizeStatus(String rawStatus) {
        if (rawStatus.equalsIgnoreCase("pending")) return "Pending";
        if (rawStatus.equalsIgnoreCase("under investigation") || rawStatus.equalsIgnoreCase("investigation") || rawStatus.equalsIgnoreCase("under_investigation")) return "Under Investigation";
        if (rawStatus.equalsIgnoreCase("resolved")) return "Resolved";
        return rawStatus;
    }
}
