package util;

import java.util.ArrayList;
import java.util.List;

/**
 * Utility to print formatted ASCII tables on the console.
 */
public class TablePrinter {

    /**
     * Prints a tabular grid using headers and rows.
     * 
     * @param headers Array of column names.
     * @param rows List of rows, where each row is an array of column values.
     */
    public static void printTable(String[] headers, List<String[]> rows) {
        if (headers == null || headers.length == 0) {
            System.out.println("No columns to print.");
            return;
        }

        int columns = headers.length;
        int[] colWidths = new int[columns];

        // Find max width of each column based on headers
        for (int i = 0; i < columns; i++) {
            colWidths[i] = headers[i] != null ? headers[i].length() : 0;
        }

        // Adjust widths based on row data
        List<String[]> cleanRows = new ArrayList<>();
        if (rows != null) {
            for (String[] row : rows) {
                String[] cleanRow = new String[columns];
                for (int i = 0; i < columns; i++) {
                    String val = "";
                    if (row != null && i < row.length && row[i] != null) {
                        val = row[i];
                    }
                    cleanRow[i] = val;
                    if (val.length() > colWidths[i]) {
                        colWidths[i] = val.length();
                    }
                }
                cleanRows.add(cleanRow);
            }
        }

        // Build the divider line
        StringBuilder divider = new StringBuilder();
        for (int width : colWidths) {
            divider.append("+");
            for (int i = 0; i < width + 2; i++) {
                divider.append("-");
            }
        }
        divider.append("+");

        String border = divider.toString();

        // Print header
        System.out.println(border);
        System.out.print("|");
        for (int i = 0; i < columns; i++) {
            String formatStr = " %-" + colWidths[i] + "s |";
            System.out.printf(formatStr, headers[i]);
        }
        System.out.println();
        System.out.println(border);

        // Print data rows
        if (cleanRows.isEmpty()) {
            System.out.print("|");
            // Print a centered empty message across the table
            int totalWidth = border.length() - 2; // Subtract start/end '|' and '+' chars roughly
            StringBuilder space = new StringBuilder();
            String msg = "No records found";
            int pad = (totalWidth - msg.length()) / 2;
            for (int i = 0; i < pad; i++) space.append(" ");
            space.append(msg);
            while (space.length() < totalWidth) space.append(" ");
            System.out.print(space.toString() + "|");
            System.out.println();
        } else {
            for (String[] row : cleanRows) {
                System.out.print("|");
                for (int i = 0; i < columns; i++) {
                    String formatStr = " %-" + colWidths[i] + "s |";
                    System.out.printf(formatStr, row[i]);
                }
                System.out.println();
            }
        }
        System.out.println(border);
    }
}
