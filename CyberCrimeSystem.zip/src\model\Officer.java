package model;

/**
 * Model class representing an Investigating Officer.
 */
public class Officer {
    private String officerId;
    private String officerName;
    private String rank;
    private String department;
    private String phone;
    private String email;

    // Default Constructor
    public Officer() {}

    // Parameterized Constructor
    public Officer(String officerId, String officerName, String rank, String department, String phone, String email) {
        this.officerId = officerId;
        this.officerName = officerName;
        this.rank = rank;
        this.department = department;
        this.phone = phone;
        this.email = email;
    }

    // Getters and Setters
    public String getOfficerId() {
        return officerId;
    }

    public void setOfficerId(String officerId) {
        this.officerId = officerId;
    }

    public String getOfficerName() {
        return officerName;
    }

    public void setOfficerName(String officerName) {
        this.officerName = officerName;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Officer{" +
                "officerId='" + officerId + '\'' +
                ", officerName='" + officerName + '\'' +
                ", rank='" + rank + '\'' +
                ", department='" + department + '\'' +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
