package main;

import model.Victim;
import model.Officer;
import model.Complaint;
import model.Evidence;
import service.VictimService;
import service.OfficerService;
import service.ComplaintService;
import service.EvidenceService;
import util.MongoDBConnection;
import util.TablePrinter;

import java.util.ArrayList;
import java.util.List;

/**
 * Programmatic test suite to verify connectivity, validations, relationships, and CRUD behavior.
 */
public class VerificationTest {
    public static void main(String[] args) {
        System.out.println("==========================================================");
        System.out.println("      RUNNING SYSTEM VERIFICATION SUITE                  ");
        System.out.println("==========================================================\n");

        if (MongoDBConnection.getDatabase() == null) {
            System.err.println("[FAIL] Could not connect to MongoDB. Ensure it is running.");
            System.exit(1);
        }

        VictimService victimService = new VictimService();
        OfficerService officerService = new OfficerService();
        ComplaintService complaintService = new ComplaintService();
        EvidenceService evidenceService = new EvidenceService();

        // Cleanup any leftovers from previous test run
        System.out.println("[Step 0] Cleaning up any old test records...");
        evidenceService.deleteEvidence("TEST-EVD-101");
        complaintService.deleteComplaint("TEST-CMP-101");
        victimService.deleteVictim("TEST-VIC-101");
        officerService.deleteOfficer("TEST-OFC-101");
        System.out.println("Cleanup completed.\n");

        // Test 1: Add Victim
        System.out.println("[Test 1] Registering a new Victim...");
        Victim victim = new Victim("TEST-VIC-101", "Jane Doe", 30, "Female", "9876543210", "jane.doe@test.com", "123 Cyber Way", "Tech City", "Digital State");
        String vRes = victimService.addVictim(victim);
        System.out.println("Result: " + vRes);
        if (!vRes.startsWith("Success")) {
            System.err.println("[FAIL] Failed to register victim.");
            System.exit(1);
        }

        // Test 2: Add Duplicate Victim ID
        System.out.println("\n[Test 2] Checking duplicate Victim ID block...");
        String vDupRes = victimService.addVictim(victim);
        System.out.println("Result (Expected Error): " + vDupRes);
        if (!vDupRes.startsWith("Error")) {
            System.err.println("[FAIL] Duplicate Victim ID was not blocked!");
            System.exit(1);
        }

        // Test 3: Add Officer
        System.out.println("\n[Test 3] Registering a new Officer...");
        Officer officer = new Officer("TEST-OFC-101", "Inspector Watson", "Senior Inspector", "Cyber Forensics", "9123456789", "watson@cyber.gov");
        String oRes = officerService.addOfficer(officer);
        System.out.println("Result: " + oRes);
        if (!oRes.startsWith("Success")) {
            System.err.println("[FAIL] Failed to register officer.");
            System.exit(1);
        }

        // Test 4: Register Complaint
        System.out.println("\n[Test 4] Registering a new Complaint linked to the Victim and Officer...");
        Complaint complaint = new Complaint("TEST-CMP-101", "TEST-VIC-101", "TEST-OFC-101", "Phishing Scam", "Victim clicked a spoofed banking link losing funds.", "2026-06-15", "Pending", "Online");
        String cRes = complaintService.addComplaint(complaint);
        System.out.println("Result: " + cRes);
        if (!cRes.startsWith("Success")) {
            System.err.println("[FAIL] Failed to register complaint.");
            System.exit(1);
        }

        // Test 5: Verify Deletion Block on Victim due to linked Complaint
        System.out.println("\n[Test 5] Checking relationship integrity block: Deleting Victim while complaint exists...");
        String vDelRes = victimService.deleteVictim("TEST-VIC-101");
        System.out.println("Result (Expected Error): " + vDelRes);
        if (!vDelRes.startsWith("Error")) {
            System.err.println("[FAIL] Deletion of victim with active complaints was not blocked!");
            System.exit(1);
        }

        // Test 6: Verify Deletion Block on Officer due to assigned Complaint
        System.out.println("\n[Test 6] Checking relationship integrity block: Deleting Officer while assigned to complaint...");
        String oDelRes = officerService.deleteOfficer("TEST-OFC-101");
        System.out.println("Result (Expected Error): " + oDelRes);
        if (!oDelRes.startsWith("Error")) {
            System.err.println("[FAIL] Deletion of officer assigned to active complaints was not blocked!");
            System.exit(1);
        }

        // Test 7: Add Evidence
        System.out.println("\n[Test 7] Registering Evidence linked to the Complaint...");
        Evidence evidence = new Evidence("TEST-EVD-101", "TEST-CMP-101", "Browser History Log", "history_log.txt", "CSV log of redirects to malicious site.", "2026-06-15");
        String eRes = evidenceService.addEvidence(evidence);
        System.out.println("Result: " + eRes);
        if (!eRes.startsWith("Success")) {
            System.err.println("[FAIL] Failed to register evidence.");
            System.exit(1);
        }

        // Test 8: Displaying tabular outputs via TablePrinter
        System.out.println("\n[Test 8] Displaying records via TablePrinter...");
        List<Victim> victims = new ArrayList<>();
        victims.add(victimService.getVictimById("TEST-VIC-101"));
        String[] vHeaders = {"Victim ID", "Name", "Age", "Phone", "Email", "City"};
        List<String[]> vRows = new ArrayList<>();
        for (Victim v : victims) {
            vRows.add(new String[]{v.getVictimId(), v.getVictimName(), String.valueOf(v.getAge()), v.getPhone(), v.getEmail(), v.getCity()});
        }
        TablePrinter.printTable(vHeaders, vRows);

        // Test 9: Cascade delete Complaint and linked Evidence
        System.out.println("\n[Test 9] Deleting Complaint and verifying cascade deletion of Evidence...");
        String cDelRes = complaintService.deleteComplaint("TEST-CMP-101");
        System.out.println("Result: " + cDelRes);
        if (!cDelRes.startsWith("Success")) {
            System.err.println("[FAIL] Failed to delete complaint.");
            System.exit(1);
        }
        
        Evidence checkEvd = evidenceService.getEvidenceById("TEST-EVD-101");
        if (checkEvd != null) {
            System.err.println("[FAIL] Evidence record TEST-EVD-101 was not cascade deleted!");
            System.exit(1);
        } else {
            System.out.println("Verified: Evidence TEST-EVD-101 cascade deleted successfully.");
        }

        // Test 10: Clean up Victim and Officer
        System.out.println("\n[Test 10] Deleting Victim and Officer (now that complaint is deleted)...");
        String vFinalDelRes = victimService.deleteVictim("TEST-VIC-101");
        String oFinalDelRes = officerService.deleteOfficer("TEST-OFC-101");
        System.out.println("Victim Deletion: " + vFinalDelRes);
        System.out.println("Officer Deletion: " + oFinalDelRes);

        if (!vFinalDelRes.startsWith("Success") || !oFinalDelRes.startsWith("Success")) {
            System.err.println("[FAIL] Final cleanup deletion failed.");
            System.exit(1);
        }

        System.out.println("\n==========================================================");
        System.out.println("      ALL TESTS PASSED SUCCESSFULLY!                      ");
        System.out.println("      System is fully functional, secure, and compliant. ");
        System.out.println("==========================================================");

        MongoDBConnection.closeConnection();
    }
}
