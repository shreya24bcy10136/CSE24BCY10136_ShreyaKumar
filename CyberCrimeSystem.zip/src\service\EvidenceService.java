package service;

import dao.EvidenceDAO;
import dao.ComplaintDAO;
import model.Evidence;
import model.Complaint;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Service class for managing Evidence, validating relationships and input details.
 */
public class EvidenceService {
    private final EvidenceDAO evidenceDAO = new EvidenceDAO();
    private final ComplaintDAO complaintDAO = new ComplaintDAO();

    /**
     * Validates and adds new evidence.
     */
    public String addEvidence(Evidence evidence) {
        if (evidence.getEvidenceId() == null || evidence.getEvidenceId().trim().isEmpty()) {
            return "Error: Evidence ID cannot be empty.";
        }
        if (evidence.getEvidenceType() == null || evidence.getEvidenceType().trim().isEmpty()) {
            return "Error: Evidence Type cannot be empty.";
        }
        if (evidence.getFileName() == null || evidence.getFileName().trim().isEmpty()) {
            return "Error: File Name cannot be empty.";
        }
        if (evidence.getDescription() == null || evidence.getDescription().trim().isEmpty()) {
            return "Error: Description cannot be empty.";
        }

        // Duplicate check
        if (evidenceDAO.getEvidenceById(evidence.getEvidenceId()) != null) {
            return "Error: Evidence ID '" + evidence.getEvidenceId() + "' already exists.";
        }

        // Referential Integrity check: Complaint
        if (evidence.getComplaintId() == null || complaintDAO.getComplaintById(evidence.getComplaintId()) == null) {
            return "Error: Referenced Complaint ID '" + evidence.getComplaintId() + "' does not exist.";
        }

        // Default collected date to current date if empty
        if (evidence.getCollectedDate() == null || evidence.getCollectedDate().trim().isEmpty()) {
            evidence.setCollectedDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        }

        boolean success = evidenceDAO.addEvidence(evidence);
        return success ? "Success: Evidence record registered successfully!" : "Error: Database insertion failed.";
    }

    /**
     * Retrieves all evidence records.
     */
    public List<Evidence> getAllEvidence() {
        return evidenceDAO.getAllEvidence();
    }

    /**
     * Searches evidence by ID.
     */
    public Evidence getEvidenceById(String evidenceId) {
        if (evidenceId == null || evidenceId.trim().isEmpty()) {
            return null;
        }
        return evidenceDAO.getEvidenceById(evidenceId.trim());
    }

    /**
     * Validates and updates evidence details.
     */
    public String updateEvidence(Evidence evidence) {
        if (evidence.getEvidenceId() == null || evidence.getEvidenceId().trim().isEmpty()) {
            return "Error: Evidence ID cannot be empty.";
        }

        Evidence existing = evidenceDAO.getEvidenceById(evidence.getEvidenceId());
        if (existing == null) {
            return "Error: Evidence with ID '" + evidence.getEvidenceId() + "' not found.";
        }

        if (evidence.getEvidenceType() == null || evidence.getEvidenceType().trim().isEmpty()) {
            return "Error: Evidence Type cannot be empty.";
        }
        if (evidence.getFileName() == null || evidence.getFileName().trim().isEmpty()) {
            return "Error: File Name cannot be empty.";
        }
        if (evidence.getDescription() == null || evidence.getDescription().trim().isEmpty()) {
            return "Error: Description cannot be empty.";
        }

        // Validate referencing Complaint ID
        if (evidence.getComplaintId() == null || complaintDAO.getComplaintById(evidence.getComplaintId()) == null) {
            return "Error: Referenced Complaint ID '" + evidence.getComplaintId() + "' does not exist.";
        }

        // Preserve collected date if not provided in update payload
        if (evidence.getCollectedDate() == null || evidence.getCollectedDate().trim().isEmpty()) {
            evidence.setCollectedDate(existing.getCollectedDate());
        }

        boolean success = evidenceDAO.updateEvidence(evidence);
        return success ? "Success: Evidence record updated successfully!" : "Error: Database update failed.";
    }

    /**
     * Deletes evidence record.
     */
    public String deleteEvidence(String evidenceId) {
        if (evidenceId == null || evidenceId.trim().isEmpty()) {
            return "Error: Evidence ID cannot be empty.";
        }

        Evidence existing = evidenceDAO.getEvidenceById(evidenceId);
        if (existing == null) {
            return "Error: Evidence record not found with ID '" + evidenceId + "'.";
        }

        boolean success = evidenceDAO.deleteEvidence(evidenceId);
        return success ? "Success: Evidence record deleted successfully!" : "Error: Database deletion failed.";
    }

    /**
     * Helper to retrieve evidence list by Complaint ID.
     */
    public List<Evidence> getEvidenceByComplaintId(String complaintId) {
        return evidenceDAO.getEvidenceByComplaintId(complaintId);
    }
}
