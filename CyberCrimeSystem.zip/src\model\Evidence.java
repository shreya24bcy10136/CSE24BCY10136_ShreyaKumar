package model;

/**
 * Model class representing Digital Evidence.
 */
public class Evidence {
    private String evidenceId;
    private String complaintId; // Reference to Complaint
    private String evidenceType;
    private String fileName;
    private String description;
    private String collectedDate;

    // Default Constructor
    public Evidence() {}

    // Parameterized Constructor
    public Evidence(String evidenceId, String complaintId, String evidenceType, 
                    String fileName, String description, String collectedDate) {
        this.evidenceId = evidenceId;
        this.complaintId = complaintId;
        this.evidenceType = evidenceType;
        this.fileName = fileName;
        this.description = description;
        this.collectedDate = collectedDate;
    }

    // Getters and Setters
    public String getEvidenceId() {
        return evidenceId;
    }

    public void setEvidenceId(String evidenceId) {
        this.evidenceId = evidenceId;
    }

    public String getComplaintId() {
        return complaintId;
    }

    public void setComplaintId(String complaintId) {
        this.complaintId = complaintId;
    }

    public String getEvidenceType() {
        return evidenceType;
    }

    public void setEvidenceType(String evidenceType) {
        this.evidenceType = evidenceType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCollectedDate() {
        return collectedDate;
    }

    public void setCollectedDate(String collectedDate) {
        this.collectedDate = collectedDate;
    }

    @Override
    public String toString() {
        return "Evidence{" +
                "evidenceId='" + evidenceId + '\'' +
                ", complaintId='" + complaintId + '\'' +
                ", evidenceType='" + evidenceType + '\'' +
                ", fileName='" + fileName + '\'' +
                ", description='" + description + '\'' +
                ", collectedDate='" + collectedDate + '\'' +
                '}';
    }
}
