package dao;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import model.Evidence;
import org.bson.Document;
import org.bson.conversions.Bson;
import util.MongoDBConnection;

import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Evidence entity.
 */
public class EvidenceDAO {
    private static final String COLLECTION_NAME = "evidence";

    private MongoCollection<Document> getCollection() {
        MongoDatabase db = MongoDBConnection.getDatabase();
        if (db == null) {
            throw new RuntimeException("Database connection is not available.");
        }
        return db.getCollection(COLLECTION_NAME);
    }

    private Document evidenceToDocument(Evidence e) {
        return new Document("evidenceId", e.getEvidenceId())
                .append("complaintId", e.getComplaintId())
                .append("evidenceType", e.getEvidenceType())
                .append("fileName", e.getFileName())
                .append("description", e.getDescription())
                .append("collectedDate", e.getCollectedDate());
    }

    private Evidence documentToEvidence(Document doc) {
        if (doc == null) return null;
        return new Evidence(
                doc.getString("evidenceId"),
                doc.getString("complaintId"),
                doc.getString("evidenceType"),
                doc.getString("fileName"),
                doc.getString("description"),
                doc.getString("collectedDate")
        );
    }

    public boolean addEvidence(Evidence evidence) {
        try {
            getCollection().insertOne(evidenceToDocument(evidence));
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to add evidence: " + e.getMessage());
            return false;
        }
    }

    public List<Evidence> getAllEvidence() {
        List<Evidence> list = new ArrayList<>();
        try {
            for (Document doc : getCollection().find()) {
                list.add(documentToEvidence(doc));
            }
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to retrieve evidence records: " + e.getMessage());
        }
        return list;
    }

    public Evidence getEvidenceById(String evidenceId) {
        try {
            Document doc = getCollection().find(Filters.eq("evidenceId", evidenceId)).first();
            return documentToEvidence(doc);
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to find evidence by ID: " + e.getMessage());
            return null;
        }
    }

    public boolean updateEvidence(Evidence evidence) {
        try {
            Bson filter = Filters.eq("evidenceId", evidence.getEvidenceId());
            Bson updates = Updates.combine(
                    Updates.set("complaintId", evidence.getComplaintId()),
                    Updates.set("evidenceType", evidence.getEvidenceType()),
                    Updates.set("fileName", evidence.getFileName()),
                    Updates.set("description", evidence.getDescription()),
                    Updates.set("collectedDate", evidence.getCollectedDate())
            );
            getCollection().updateOne(filter, updates);
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to update evidence: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteEvidence(String evidenceId) {
        try {
            getCollection().deleteOne(Filters.eq("evidenceId", evidenceId));
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to delete evidence: " + e.getMessage());
            return false;
        }
    }

    public List<Evidence> getEvidenceByComplaintId(String complaintId) {
        List<Evidence> list = new ArrayList<>();
        try {
            for (Document doc : getCollection().find(Filters.eq("complaintId", complaintId))) {
                list.add(documentToEvidence(doc));
            }
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to retrieve evidence for complaint: " + e.getMessage());
        }
        return list;
    }

    public boolean deleteEvidenceByComplaintId(String complaintId) {
        try {
            getCollection().deleteMany(Filters.eq("complaintId", complaintId));
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to cascade delete evidence for complaint: " + e.getMessage());
            return false;
        }
    }
}
