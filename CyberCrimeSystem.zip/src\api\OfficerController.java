package api;

import model.Officer;
import service.OfficerService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Controller exposing Officer Management REST APIs.
 */
@RestController
@RequestMapping("/api/officers")
@Tag(name = "Officer Management", description = "CRUD operations for registering, updating, viewing, and deleting investigating officers")
public class OfficerController {
    private final OfficerService officerService = new OfficerService();

    @GetMapping
    public List<Officer> getAllOfficers() {
        return officerService.getAllOfficers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Officer> getOfficerById(@PathVariable String id) {
        Officer officer = officerService.getOfficerById(id);
        if (officer == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(officer);
    }

    @PostMapping
    public ResponseEntity<ApiResponse> addOfficer(@RequestBody Officer officer) {
        String result = officerService.addOfficer(officer);
        return buildResponse(result);
    }

    @PutMapping
    public ResponseEntity<ApiResponse> updateOfficer(@RequestBody Officer officer) {
        String result = officerService.updateOfficer(officer);
        return buildResponse(result);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteOfficer(@PathVariable String id) {
        String result = officerService.deleteOfficer(id);
        return buildResponse(result);
    }

    private ResponseEntity<ApiResponse> buildResponse(String serviceResult) {
        if (serviceResult == null) {
            return ResponseEntity.internalServerError().body(new ApiResponse(false, "Unknown database error."));
        }
        if (serviceResult.startsWith("Success:")) {
            return ResponseEntity.ok(new ApiResponse(true, serviceResult.replaceFirst("^Success:\\s*", "")));
        } else {
            return ResponseEntity.badRequest().body(new ApiResponse(false, serviceResult.replaceFirst("^Error:\\s*", "")));
        }
    }
}
