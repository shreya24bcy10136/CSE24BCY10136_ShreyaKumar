package dao;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import model.Complaint;
import org.bson.Document;
import org.bson.conversions.Bson;
import util.MongoDBConnection;

import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Complaint entity.
 */
public class ComplaintDAO {
    private static final String COLLECTION_NAME = "complaints";

    private MongoCollection<Document> getCollection() {
        MongoDatabase db = MongoDBConnection.getDatabase();
        if (db == null) {
            throw new RuntimeException("Database connection is not available.");
        }
        return db.getCollection(COLLECTION_NAME);
    }

    private Document complaintToDocument(Complaint c) {
        return new Document("complaintId", c.getComplaintId())
                .append("victimId", c.getVictimId())
                .append("officerId", c.getOfficerId())
                .append("crimeType", c.getCrimeType())
                .append("complaintDescription", c.getComplaintDescription())
                .append("complaintDate", c.getComplaintDate())
                .append("status", c.getStatus())
                .append("location", c.getLocation());
    }

    private Complaint documentToComplaint(Document doc) {
        if (doc == null) return null;
        return new Complaint(
                doc.getString("complaintId"),
                doc.getString("victimId"),
                doc.getString("officerId"),
                doc.getString("crimeType"),
                doc.getString("complaintDescription"),
                doc.getString("complaintDate"),
                doc.getString("status"),
                doc.getString("location")
        );
    }

    public boolean addComplaint(Complaint complaint) {
        try {
            getCollection().insertOne(complaintToDocument(complaint));
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to add complaint: " + e.getMessage());
            return false;
        }
    }

    public List<Complaint> getAllComplaints() {
        List<Complaint> complaints = new ArrayList<>();
        try {
            for (Document doc : getCollection().find()) {
                complaints.add(documentToComplaint(doc));
            }
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to retrieve complaints: " + e.getMessage());
        }
        return complaints;
    }

    public Complaint getComplaintById(String complaintId) {
        try {
            Document doc = getCollection().find(Filters.eq("complaintId", complaintId)).first();
            return documentToComplaint(doc);
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to find complaint by ID: " + e.getMessage());
            return null;
        }
    }

    public boolean updateComplaint(Complaint complaint) {
        try {
            Bson filter = Filters.eq("complaintId", complaint.getComplaintId());
            Bson updates = Updates.combine(
                    Updates.set("crimeType", complaint.getCrimeType()),
                    Updates.set("complaintDescription", complaint.getComplaintDescription()),
                    Updates.set("complaintDate", complaint.getComplaintDate()),
                    Updates.set("location", complaint.getLocation()),
                    Updates.set("victimId", complaint.getVictimId()),
                    Updates.set("officerId", complaint.getOfficerId())
            );
            getCollection().updateOne(filter, updates);
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to update complaint: " + e.getMessage());
            return false;
        }
    }

    public boolean updateComplaintStatus(String complaintId, String status) {
        try {
            Bson filter = Filters.eq("complaintId", complaintId);
            Bson update = Updates.set("status", status);
            getCollection().updateOne(filter, update);
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to update complaint status: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteComplaint(String complaintId) {
        try {
            getCollection().deleteOne(Filters.eq("complaintId", complaintId));
            return true;
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to delete complaint: " + e.getMessage());
            return false;
        }
    }

    public List<Complaint> getComplaintsByVictimId(String victimId) {
        List<Complaint> complaints = new ArrayList<>();
        try {
            for (Document doc : getCollection().find(Filters.eq("victimId", victimId))) {
                complaints.add(documentToComplaint(doc));
            }
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to retrieve complaints for victim: " + e.getMessage());
        }
        return complaints;
    }

    public List<Complaint> getComplaintsByOfficerId(String officerId) {
        List<Complaint> complaints = new ArrayList<>();
        try {
            for (Document doc : getCollection().find(Filters.eq("officerId", officerId))) {
                complaints.add(documentToComplaint(doc));
            }
        } catch (Exception e) {
            System.err.println("[DAO Error] Failed to retrieve complaints for officer: " + e.getMessage());
        }
        return complaints;
    }
}
