package main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Spring Boot application entry point for the Cyber Crime Complaint Management System REST API.
 */
@SpringBootApplication
@ComponentScan(basePackages = {"main", "api", "service", "dao", "util"})
public class ApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApiApplication.class, args);
    }
}
