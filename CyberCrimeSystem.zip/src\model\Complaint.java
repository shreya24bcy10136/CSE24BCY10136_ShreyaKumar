package model;

/**
 * Model class representing a Cyber Crime Complaint.
 */
public class Complaint {
    private String complaintId;
    private String victimId; // Reference to Victim
    private String officerId; // Reference to Officer
    private String crimeType;
    private String complaintDescription;
    private String complaintDate;
    private String status; // Pending, Under Investigation, Resolved
    private String location;

    // Default Constructor
    public Complaint() {}

    // Parameterized Constructor
    public Complaint(String complaintId, String victimId, String officerId, String crimeType, 
                     String complaintDescription, String complaintDate, String status, String location) {
        this.complaintId = complaintId;
        this.victimId = victimId;
        this.officerId = officerId;
        this.crimeType = crimeType;
        this.complaintDescription = complaintDescription;
        this.complaintDate = complaintDate;
        this.status = status;
        this.location = location;
    }

    // Getters and Setters
    public String getComplaintId() {
        return complaintId;
    }

    public void setComplaintId(String complaintId) {
        this.complaintId = complaintId;
    }

    public String getVictimId() {
        return victimId;
    }

    public void setVictimId(String victimId) {
        this.victimId = victimId;
    }

    public String getOfficerId() {
        return officerId;
    }

    public void setOfficerId(String officerId) {
        this.officerId = officerId;
    }

    public String getCrimeType() {
        return crimeType;
    }

    public void setCrimeType(String crimeType) {
        this.crimeType = crimeType;
    }

    public String getComplaintDescription() {
        return complaintDescription;
    }

    public void setComplaintDescription(String complaintDescription) {
        this.complaintDescription = complaintDescription;
    }

    public String getComplaintDate() {
        return complaintDate;
    }

    public void setComplaintDate(String complaintDate) {
        this.complaintDate = complaintDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Complaint{" +
                "complaintId='" + complaintId + '\'' +
                ", victimId='" + victimId + '\'' +
                ", officerId='" + officerId + '\'' +
                ", crimeType='" + crimeType + '\'' +
                ", complaintDescription='" + complaintDescription + '\'' +
                ", complaintDate='" + complaintDate + '\'' +
                ", status='" + status + '\'' +
                ", location='" + location + '\'' +
                '}';
    }
}
