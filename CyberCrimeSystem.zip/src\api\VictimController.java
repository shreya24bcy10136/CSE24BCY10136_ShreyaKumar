package api;

import model.Victim;
import service.VictimService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Controller exposing Victim Management REST APIs.
 */
@RestController
@RequestMapping("/api/victims")
@Tag(name = "Victim Management", description = "CRUD operations for registering, updating, viewing, and deleting victims")
public class VictimController {
    private final VictimService victimService = new VictimService();

    @GetMapping
    public List<Victim> getAllVictims() {
        return victimService.getAllVictims();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Victim> getVictimById(@PathVariable String id) {
        Victim victim = victimService.getVictimById(id);
        if (victim == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(victim);
    }

    @PostMapping
    public ResponseEntity<ApiResponse> addVictim(@RequestBody Victim victim) {
        String result = victimService.addVictim(victim);
        return buildResponse(result);
    }

    @PutMapping
    public ResponseEntity<ApiResponse> updateVictim(@RequestBody Victim victim) {
        String result = victimService.updateVictim(victim);
        return buildResponse(result);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteVictim(@PathVariable String id) {
        String result = victimService.deleteVictim(id);
        return buildResponse(result);
    }

    private ResponseEntity<ApiResponse> buildResponse(String serviceResult) {
        if (serviceResult == null) {
            return ResponseEntity.internalServerError().body(new ApiResponse(false, "Unknown database error."));
        }
        if (serviceResult.startsWith("Success:")) {
            return ResponseEntity.ok(new ApiResponse(true, serviceResult.replaceFirst("^Success:\\s*", "")));
        } else {
            return ResponseEntity.badRequest().body(new ApiResponse(false, serviceResult.replaceFirst("^Error:\\s*", "")));
        }
    }
}
